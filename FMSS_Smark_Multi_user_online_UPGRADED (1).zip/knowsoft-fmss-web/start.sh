#!/bin/bash
cd "$(dirname "$0")/backend"
if [ ! -d "venv" ]; then
  python3 -m venv venv
  source venv/bin/activate
  pip install -r requirements.txt
else
  source venv/bin/activate
fi
echo "Starting Knowsoft FMSS Web on http://0.0.0.0:8000"
uvicorn main:app --reload --host 0.0.0.0 --port 8000
