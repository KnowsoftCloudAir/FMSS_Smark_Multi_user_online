
def _migrate_schema(engine):
    """Add new columns if missing (SQLite / Postgres safe try)."""
    from sqlalchemy import text
    alters = [
        ("project_codes", "budget_amount", "FLOAT DEFAULT 0"),
        ("project_codes", "start_date", "DATE"),
        ("project_codes", "end_date", "DATE"),
        ("payment_requests", "project_code_id", "INTEGER"),
        ("payment_requests", "amount_in_words", "VARCHAR(500)"),
        ("payment_requests", "line_items_json", "TEXT"),
        ("bank_statement_sessions", "bank_charges", "FLOAT DEFAULT 0"),
        ("bank_statement_sessions", "bank_charges_note", "TEXT"),
        ("bank_statement_sessions", "unpresented_cheques", "FLOAT DEFAULT 0"),
        ("bank_statement_sessions", "deposits_in_transit", "FLOAT DEFAULT 0"),
        ("bank_statement_sessions", "status", "VARCHAR(20) DEFAULT 'draft'"),
        ("bank_statement_sessions", "approved_by", "INTEGER"),
        ("bank_statement_sessions", "approved_at", "TIMESTAMP"),
        ("bank_statement_sessions", "approver_stamp", "VARCHAR(120)"),
        ("procurement_rfqs", "committee_id", "INTEGER"),
        ("procurement_rfqs", "requesting_officer_id", "INTEGER"),
    ]
    with engine.begin() as conn:
        for table, col, typ in alters:
            try:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {typ}"))
            except Exception:
                pass

from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, date
from typing import Optional, List, Dict, Any
from pathlib import Path
from werkzeug.utils import secure_filename
import os, shutil, re, json, zipfile, io, csv, secrets

from database import engine, get_db, Base
from models import (
    User, Company, AuditLog, CompanySettings, PasswordResetToken,
    ChartOfAccount, BudgetCode, ExpenseCode, PaymentRequest, PaymentApprovalLog, Asset,
    PaymentAttachment, JournalEntry, InventoryItem, InventoryMovement,
    Vendor, AssetAccountingEntry, ProcurementService, ProcurementRFQ, ProcurementQuote, ProcurementCommittee, ProcurementCommitteeMember, QuoteMemberScore, PurchaseOrder, ProcurementDocument, GoodsReceipt, ProcurementInvoice, BankReconState, CorrectionRequest, BankStatementSession, StoredReport, PaymentLineItem, ProjectCode
)
from schemas import (
    Token, UserCreate, UserUpdate, UserOut, CompanyRegister, CompanyOut, CompanyUpdate,
    LicenseIssue, PasswordChange, PasswordResetRequest, PasswordResetConfirm,
    COAIn, BudgetCodeIn, ExpenseCodeIn, PaymentRequestIn, PaymentAction, AssetIn,
    CompanySettingsOut
)
from reports import amount_to_words
from auth import (
    create_access_token, get_password_hash, verify_password,
    get_current_active_user, get_superadmin, get_company_admin,
    require_roles, check_company_license, generate_reset_token, generate_license_key,
    ACCESS_TOKEN_EXPIRE_MINUTES
)

Base.metadata.create_all(bind=engine)
_migrate_schema(engine)

app = FastAPI(title="Knowsoft FMSS ERP", version="2.3.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
from erp_ext import router as erp_router
app.include_router(erp_router)

# Professional upgrade: General Admin + Project Finance
try:
    from general_admin_api import router as ga_router, ensure_general_admin
    app.include_router(ga_router)
except Exception as _e:
    print("general_admin_api not loaded:", _e)
    ensure_general_admin = None
try:
    from project_finance_api import router as project_router
    app.include_router(project_router)
except Exception as _e:
    print("project_finance_api not loaded:", _e)
try:
    from demo_control import router as demo_router
    app.include_router(demo_router)
except Exception as _e:
    print("demo_control not loaded:", _e)

STATIC_DIR = Path(__file__).parent.parent / "static"
FRONTEND_DIR = Path(__file__).parent.parent / "frontend"
IMAGES_DIR = STATIC_DIR / "images"
UPLOADS_DIR = STATIC_DIR / "uploads"
BACKUP_DIR = STATIC_DIR / "backups"
ARCHIVE_DIR = STATIC_DIR / "archives"
for d in (IMAGES_DIR, UPLOADS_DIR, BACKUP_DIR, ARCHIVE_DIR):
    d.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

ALLOWED_IMAGE = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
ALLOWED_DATA = {".csv", ".xlsx", ".xls", ".pdf"}


def audit(db, company_id, user, action, details):
    db.add(AuditLog(
        company_id=company_id,
        user_id=user.id if user else None,
        username=user.username if user else "system",
        action=action,
        details=details,
    ))
    db.commit()


def init_defaults(db: Session):
    # Ensure new columns exist (SQLite)
    try:
        from sqlalchemy import text
        for stmt in [
            "ALTER TABLE project_codes ADD COLUMN budget_amount FLOAT DEFAULT 0",
            "ALTER TABLE project_codes ADD COLUMN start_date DATE",
            "ALTER TABLE project_codes ADD COLUMN end_date DATE",
            "ALTER TABLE project_codes ADD COLUMN created_at DATETIME",
            "ALTER TABLE payment_requests ADD COLUMN project_code_id INTEGER",
            "ALTER TABLE payment_requests ADD COLUMN amount_in_words VARCHAR(500)",
            "ALTER TABLE payment_requests ADD COLUMN line_items_json TEXT",
        ]:
            try:
                db.execute(text(stmt))
                db.commit()
            except Exception:
                db.rollback()
    except Exception as e:
        print("migrate note:", e)

    if not db.query(CompanySettings).first():
        db.add(CompanySettings(org_name="Knowsoft FMSS ERP"))
        db.commit()

    # Platform superadmin (no company)
    sa = db.query(User).filter(User.username == "superadmin", User.company_id.is_(None)).first()
    if not sa:
        sa = User(
            company_id=None,
            username="superadmin",
            email="superadmin@knowsoft.local",
            full_name="Platform Super Admin",
            hashed_password=get_password_hash("SuperAdmin@FMSS2026!"),
            role="superadmin",
            is_active=True,
            can_access_finance=True,
            can_access_inventory=True,
            can_access_assets=True,
            can_edit_assets=True,
            can_access_vendors=True,
            can_access_reports=True,
            can_approve_payment=True,
        )
        db.add(sa)
        db.commit()
        print("✅ Superadmin: superadmin / SuperAdmin@FMSS2026!")

    demo = db.query(Company).filter(Company.slug == "demo").first()
    if not demo:
        demo = Company(
            name="Demo Organization",
            slug="demo",
            address="Lagos, Nigeria",
            status="approved",
            license_key=generate_license_key("demo"),
            license_expires=date.today() + timedelta(days=365),
            approved_at=datetime.utcnow(),
            approved_by="system",
        )
        db.add(demo)
        db.commit()
        db.refresh(demo)
        admin = User(
            company_id=demo.id,
            username="admin",
            email="admin@demo.local",
            full_name="Demo Company Admin",
            hashed_password=get_password_hash("Admin@FMSS2026!"),
            role="company_admin",
            is_active=True,
            can_access_finance=True,
            can_access_inventory=True,
            can_access_assets=True,
            can_edit_assets=True,
            can_access_vendors=True,
            can_access_reports=True,
            can_approve_payment=True,
        )
        finance = User(
            company_id=demo.id,
            username="finance",
            email="finance@demo.local",
            full_name="Demo Finance Officer",
            hashed_password=get_password_hash("Finance@FMSS2026!"),
            role="finance",
            is_active=True,
            can_access_finance=True,
            can_access_assets=True,
            can_access_reports=True,
            can_approve_payment=True,
        )
        program = User(
            company_id=demo.id,
            username="program",
            email="program@demo.local",
            full_name="Demo Program Manager",
            hashed_password=get_password_hash("Program@FMSS2026!"),
            role="program",
            is_active=True,
            can_access_reports=True,
            can_approve_payment=True,
        )
        db.add_all([admin, finance, program])
        db.commit()
        db.refresh(admin)
        db.refresh(finance)
        db.refresh(program)

        # ---- Full sample financial data ----
        coa_rows = [
            ("1000", "Cash at Bank - Main", "Cash"),
            ("1100", "Petty Cash", "Cash"),
            ("1200", "Accounts Receivable", "Asset"),
            ("1500", "Furniture & Fittings", "Asset"),
            ("1510", "IT Equipment", "Asset"),
            ("1520", "Motor Vehicles", "Asset"),
            ("2000", "Accounts Payable", "Liability"),
            ("3000", "Retained Earnings", "Equity"),
            ("4000", "Grant Income", "Income"),
            ("4100", "Other Income", "Income"),
            ("5000", "Staff Salaries", "Expense"),
            ("5100", "Office Rent", "Expense"),
            ("5200", "Travel & Transport", "Expense"),
            ("5300", "Training & Workshops", "Expense"),
            ("5400", "Utilities & Communications", "Expense"),
            ("5500", "Programme Supplies", "Expense"),
            ("5600", "Professional Fees", "Expense"),
            ("5700", "Bank Charges", "Expense"),
        ]
        coa_map = {}
        for code, name, typ in coa_rows:
            row = ChartOfAccount(company_id=demo.id, code=code, name=name, account_type=typ)
            db.add(row)
            db.flush()
            coa_map[code] = row.id

        budgets = [
            ("BUD-HEALTH-2026", "Health Programme 2026", 25000000, program.id),
            ("BUD-EDU-2026", "Education Support 2026", 18000000, program.id),
            ("BUD-OPS-2026", "Operations & Admin 2026", 8000000, finance.id),
            ("BUD-CAPEX-2026", "Capital Expenditure 2026", 12000000, admin.id),
        ]
        bud_map = {}
        for code, desc, amt, approver in budgets:
            b = BudgetCode(company_id=demo.id, code=code, description=desc, amount=amt, spent=0, default_approver_id=approver)
            db.add(b)
            db.flush()
            bud_map[code] = b.id

        expenses = [
            ("EXP-SAL", "Monthly staff salaries", bud_map["BUD-OPS-2026"], coa_map["5000"], coa_map["1000"]),
            ("EXP-RENT", "Office rent payment", bud_map["BUD-OPS-2026"], coa_map["5100"], coa_map["1000"]),
            ("EXP-TRV", "Field travel allowances", bud_map["BUD-HEALTH-2026"], coa_map["5200"], coa_map["1000"]),
            ("EXP-TRN", "Community training workshop", bud_map["BUD-EDU-2026"], coa_map["5300"], coa_map["1000"]),
            ("EXP-SUP", "Medical supplies for outreach", bud_map["BUD-HEALTH-2026"], coa_map["5500"], coa_map["1000"]),
            ("EXP-IT", "Laptops and peripherals", bud_map["BUD-CAPEX-2026"], coa_map["1510"], coa_map["1000"]),
            ("EXP-UTIL", "Electricity and internet", bud_map["BUD-OPS-2026"], coa_map["5400"], coa_map["1000"]),
            ("EXP-FEE", "External audit fees", bud_map["BUD-OPS-2026"], coa_map["5600"], coa_map["1000"]),
        ]
        exp_map = {}
        for code, desc, bid, debit, credit in expenses:
            e = ExpenseCode(
                company_id=demo.id, code=code, description=desc,
                budget_code_id=bid, default_debit_account_id=debit, default_credit_account_id=credit,
            )
            db.add(e)
            db.flush()
            exp_map[code] = e.id

        # Assets sample
        assets = [
            ("FA-001", "Toyota Hilux 2022", "Motor Vehicles", "Head Office", 18500000, 14800000, "Good", "Yes"),
            ("FA-002", "Dell Latitude Laptops (10)", "IT Equipment", "ICT Store", 4500000, 3600000, "Good", "Yes"),
            ("FA-003", "Office Furniture Set", "Furniture", "Lagos Office", 1200000, 900000, "Fair", "No"),
            ("FA-004", "Generator 50KVA", "Plant & Machinery", "Compound", 3200000, 2560000, "Good", "Yes"),
            ("FA-005", "Old Desktop PCs (5)", "IT Equipment", "Archive", 450000, 50000, "Bad", "No"),
            ("FA-006", "Projector Epson", "IT Equipment", "Training Hall", 380000, 266000, "Good", "Yes"),
            ("FA-007", "Missing Tablet", "IT Equipment", "Field", 180000, 0, "Lost", "No"),
        ]
        for num, name, cat, loc, cost, nbv, cond, ins in assets:
            db.add(Asset(
                company_id=demo.id, asset_number=num, asset_name=name, category=cat,
                location=loc, cost=cost, nbv=nbv, condition=cond, insurance=ins,
                created_by=admin.id,
            ))

        # Payment requests across workflow stages
        from datetime import timedelta as _td
        samples = [
            # paid
            ("PR-202603-0001", admin.id, bud_map["BUD-OPS-2026"], exp_map["EXP-RENT"], 850000,
             "Office rent Q1 2026", "Property Holdings Ltd", coa_map["5100"], coa_map["1000"],
             program.id, "paid", program.id, finance.id),
            ("PR-202603-0002", finance.id, bud_map["BUD-OPS-2026"], exp_map["EXP-SAL"], 4200000,
             "March 2026 payroll", "Staff Payroll Account", coa_map["5000"], coa_map["1000"],
             program.id, "paid", program.id, finance.id),
            # finance approved - ready to pay
            ("PR-202603-0003", admin.id, bud_map["BUD-CAPEX-2026"], exp_map["EXP-IT"], 2750000,
             "Purchase of 5 project laptops", "TechMart Nigeria", coa_map["1510"], coa_map["1000"],
             admin.id, "finance_approved", program.id, finance.id),
            # program approved - awaiting finance
            ("PR-202603-0004", program.id, bud_map["BUD-HEALTH-2026"], exp_map["EXP-SUP"], 1850000,
             "Outreach medical kits - Kano State", "MedSupply Co", coa_map["5500"], coa_map["1000"],
             program.id, "program_approved", program.id, None),
            # submitted - awaiting program
            ("PR-202603-0005", admin.id, bud_map["BUD-EDU-2026"], exp_map["EXP-TRN"], 980000,
             "Teacher capacity workshop - Abuja", "Training Hub Ltd", None, None,
             program.id, "submitted", None, None),
            ("PR-202603-0006", finance.id, bud_map["BUD-HEALTH-2026"], exp_map["EXP-TRV"], 640000,
             "Field monitoring travel - 3 states", "Various (staff)", None, None,
             program.id, "submitted", None, None),
            # rejected sample
            ("PR-202603-0007", admin.id, bud_map["BUD-OPS-2026"], exp_map["EXP-FEE"], 1500000,
             "Unbudgeted consultancy", "ConsultX Ltd", None, None,
             program.id, "rejected", None, None),
        ]
        for (rno, req, bid, eid, amt, narr, payee, debit, credit, appr, status, prog, fin) in samples:
            pr = PaymentRequest(
                company_id=demo.id, request_no=rno, requester_id=req,
                budget_code_id=bid, expense_code_id=eid, amount=amt,
                narration=narr, payee_name=payee,
                debit_account_id=debit, credit_account_id=credit,
                designated_approver_id=appr, status=status,
                program_approved_by=prog,
                program_approved_at=datetime.utcnow() - _td(days=2) if prog else None,
                finance_approved_by=fin,
                finance_approved_at=datetime.utcnow() - _td(days=1) if fin else None,
                paid_at=datetime.utcnow() - _td(hours=12) if status == "paid" else None,
                rejection_reason="Insufficient budget line justification" if status == "rejected" else "",
            )
            db.add(pr)
            db.flush()
            db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=req, action="submit", comment="Sample submission"))
            if status in ("program_approved", "finance_approved", "paid") and prog:
                db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=prog, action="program_approve", comment="Programme OK"))
            if status in ("finance_approved", "paid") and fin:
                db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=fin, action="finance_approve", comment="Accounts verified"))
            if status == "paid" and fin:
                db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=fin, action="pay", comment="Paid via transfer"))
            if status == "rejected":
                db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=program.id, action="reject", comment="Insufficient justification"))

        # Update spent on paid items
        paid_rent = db.query(BudgetCode).filter(BudgetCode.id == bud_map["BUD-OPS-2026"]).first()
        if paid_rent:
            paid_rent.spent = 850000 + 4200000  # rent + salary samples

        db.commit()
        
        # Inventory samples
        inv_items = [
            ("INV-001", "Paracetamol 500mg (box)", "Medical", "Health", 2500, 200),
            ("INV-002", "Exercise books (carton)", "Education", "Education", 18000, 50),
            ("INV-003", "Printer paper A4", "Stationery", "Admin", 4500, 80),
            ("INV-004", "Mosquito nets", "Medical", "Health", 3200, 150),
            ("INV-005", "USB flash drives 32GB", "IT", "ICT", 3500, 40),
        ]
        for code, name, cat, dept, cost, qty in inv_items:
            total = cost * qty
            item = InventoryItem(
                company_id=demo.id, item_code=code, item_name=name, category=cat,
                department=dept, cost_price=cost, qty_received=qty, qty_issued=0,
                balance_qty=qty, total_value=total, receive_method="Purchase",
                funding_source="Grant", debit_account_id=coa_map.get("5500"),
                credit_account_id=coa_map.get("1000"),
            )
            db.add(item)
            db.flush()
            if total > 0:
                eno = f"JE-SEED-INV-{code}"
                db.add(JournalEntry(company_id=demo.id, entry_no=eno, entry_date=date.today(),
                    source_type="inventory", source_id=item.id, account_id=coa_map["5500"],
                    description=f"Stock {code}", narration=name, debit=total, credit=0, created_by=admin.id))
                db.add(JournalEntry(company_id=demo.id, entry_no=eno, entry_date=date.today(),
                    source_type="inventory", source_id=item.id, account_id=coa_map["1000"],
                    description=f"Stock {code}", narration=name, debit=0, credit=total, created_by=admin.id))

        # Vendor samples
        vendors = [
            ("V-001", "MedSupply Co", "Lagos", "Yes", "Yes", "Yes", "Zenith Bank", 5000000, "Medical supplies"),
            ("V-002", "TechMart Nigeria", "Abuja", "Yes", "Yes", "No", "GTBank", 2750000, "IT equipment"),
            ("V-003", "Training Hub Ltd", "Abuja", "Yes", "No", "Yes", "Access Bank", 980000, "Training services"),
            ("V-004", "Property Holdings Ltd", "Lagos", "Yes", "Yes", "Yes", "UBA", 850000, "Office rent"),
        ]
        for num, name, addr, tax, reg, audit, bank, amt, desc in vendors:
            score = (25 if tax == "Yes" else 0) + (25 if reg == "Yes" else 0) + (25 if audit == "Yes" else 0) + 20
            db.add(Vendor(
                company_id=demo.id, vendor_number=num, name=name, address=addr,
                tax_clearance=tax, reg_with_govt=reg, audit_3yrs=audit, bank=bank,
                amount=amt, description=desc, score=score,
                debit_account_id=coa_map.get("5600"), credit_account_id=coa_map.get("2000"),
            ))

        # ---- Project codes (always refresh map) ----
        proj_defs = [
            ("PRJ-HLT", "Health Outreach 2026", 5000000),
            ("PRJ-EDU", "Education Support 2026", 3500000),
            ("PRJ-OPS", "Operations & Admin", 1500000),
            ("PRJ-WASH", "Water & Sanitation", 2800000),
            ("PRJ-CAP", "Capital / Equipment", 4200000),
        ]
        proj_map = {}
        for code, name, bud in proj_defs:
            pc = db.query(ProjectCode).filter(ProjectCode.company_id == demo.id, ProjectCode.code == code).first()
            if not pc:
                kwargs = dict(company_id=demo.id, code=code, name=name, description=name)
                if hasattr(ProjectCode, "budget_amount"):
                    kwargs["budget_amount"] = bud
                pc = ProjectCode(**kwargs)
                db.add(pc)
                db.flush()
            else:
                if hasattr(pc, "budget_amount") and not (pc.budget_amount or 0):
                    try:
                        pc.budget_amount = bud
                    except Exception:
                        pass
            proj_map[code] = pc.id
        db.commit()

        # Tag existing journal lines with projects where missing
        jes = db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.project_code_id.is_(None)).all()
        for i, j in enumerate(jes):
            codes = list(proj_map.values())
            j.project_code_id = codes[i % len(codes)]
            db.add(j)

        # Extra project-coded postings (income + expenses)
        extra_jes = [
            ("JE-PRJ-HLT-01", "1000", "4000", 2000000, "Grant received — Health", "PRJ-HLT"),
            ("JE-PRJ-HLT-02", "5500", "1000", 450000, "Medical kits — field", "PRJ-HLT"),
            ("JE-PRJ-EDU-01", "1000", "4000", 1500000, "Grant received — Education", "PRJ-EDU"),
            ("JE-PRJ-EDU-02", "5300", "1000", 320000, "Teacher training workshop", "PRJ-EDU"),
            ("JE-PRJ-WASH-01", "5500", "1000", 280000, "Water treatment supplies", "PRJ-WASH"),
            ("JE-PRJ-OPS-01", "5100", "1000", 850000, "HQ rent allocation", "PRJ-OPS"),
            ("JE-PRJ-CAP-01", "1510", "1000", 1250000, "Project laptops", "PRJ-CAP"),
        ]
        for eno, dr, cr, amt, desc, pcode in extra_jes:
            if db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.entry_no == eno).first():
                continue
            pid = proj_map.get(pcode)
            db.add(JournalEntry(
                company_id=demo.id, entry_no=eno, entry_date=date.today() - _td(days=5),
                source_type="manual", account_id=coa_map[dr], project_code_id=pid,
                description=desc, narration=f"Project {pcode}", debit=amt, credit=0, created_by=finance.id,
            ))
            db.add(JournalEntry(
                company_id=demo.id, entry_no=eno, entry_date=date.today() - _td(days=5),
                source_type="manual", account_id=coa_map[cr], project_code_id=pid,
                description=desc, narration=f"Project {pcode}", debit=0, credit=amt, created_by=finance.id,
            ))
        db.commit()

        # Update assets with project + accounts
        for a in db.query(Asset).filter(Asset.company_id == demo.id).all():
            a.assigned_to = a.assigned_to or "Head Office Pool"
            a.debit_account_id = a.debit_account_id or coa_map.get("1510")
            a.credit_account_id = a.credit_account_id or coa_map.get("1000")
            a.useful_life = a.useful_life or 5.0
            if not a.project_code_id:
                a.project_code_id = proj_map.get("PRJ-CAP") or proj_map.get("PRJ-OPS")

        # ---- Inventory with project-linked postings ----
        inv_samples = [
            ("INV-MED-001", "ORS Sachets (box)", "Medical", 2500, 40, "PRJ-HLT"),
            ("INV-MED-002", "First aid kits", "Medical", 15000, 25, "PRJ-HLT"),
            ("INV-EDU-001", "Exercise books (carton)", "Education", 8000, 30, "PRJ-EDU"),
            ("INV-WASH-001", "Water purification tablets", "WASH", 4500, 50, "PRJ-WASH"),
            ("INV-OPS-001", "Office stationery pack", "Admin", 3500, 20, "PRJ-OPS"),
        ]
        for code, name, cat, cost, qty, pcode in inv_samples:
            if db.query(InventoryItem).filter(InventoryItem.company_id == demo.id, InventoryItem.item_code == code).first():
                continue
            total = cost * qty
            item = InventoryItem(
                company_id=demo.id, item_code=code, item_name=name, category=cat,
                cost_price=cost, qty_received=qty, balance_qty=qty, total_value=total,
                department="Programmes", funding_source="Grant",
                debit_account_id=coa_map.get("5500"), credit_account_id=coa_map.get("1000"),
                project_code_id=proj_map.get(pcode),
            )
            db.add(item); db.flush()
            db.add(InventoryMovement(
                company_id=demo.id, item_id=item.id, movement_type="receive",
                quantity=qty, unit_cost=cost, total=total, narration=f"Opening stock {pcode}",
                debit_account_id=coa_map.get("5500"), credit_account_id=coa_map.get("1000"),
                project_code_id=proj_map.get(pcode), created_by=finance.id,
            ))
            eno = f"JE-INV-{code}"
            if not db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.entry_no == eno).first():
                db.add(JournalEntry(
                    company_id=demo.id, entry_no=eno, entry_date=date.today() - _td(days=3),
                    source_type="inventory", source_id=item.id, account_id=coa_map["5500"],
                    project_code_id=proj_map.get(pcode),
                    description=f"Stock receive {code}", narration=name, debit=total, credit=0, created_by=finance.id,
                ))
                db.add(JournalEntry(
                    company_id=demo.id, entry_no=eno, entry_date=date.today() - _td(days=3),
                    source_type="inventory", source_id=item.id, account_id=coa_map["1000"],
                    project_code_id=proj_map.get(pcode),
                    description=f"Stock receive {code}", narration=name, debit=0, credit=total, created_by=finance.id,
                ))
            # partial issue for one item
            if code == "INV-MED-001":
                issue_qty = 10
                issue_total = issue_qty * cost
                item.qty_issued = issue_qty
                item.balance_qty = qty - issue_qty
                item.total_value = item.balance_qty * cost
                db.add(InventoryMovement(
                    company_id=demo.id, item_id=item.id, movement_type="issue",
                    quantity=issue_qty, unit_cost=cost, total=issue_total,
                    narration="Issued to Kano outreach", debit_account_id=coa_map.get("5500"),
                    credit_account_id=coa_map.get("1000"), project_code_id=proj_map.get(pcode), created_by=program.id,
                ))
                eno2 = f"JE-ISS-{code}"
                db.add(JournalEntry(
                    company_id=demo.id, entry_no=eno2, entry_date=date.today() - _td(days=1),
                    source_type="inventory", source_id=item.id, account_id=coa_map["5500"],
                    project_code_id=proj_map.get(pcode),
                    description=f"Stock issue {code}", narration="Kano outreach", debit=issue_total, credit=0, created_by=program.id,
                ))
                db.add(JournalEntry(
                    company_id=demo.id, entry_no=eno2, entry_date=date.today() - _td(days=1),
                    source_type="inventory", source_id=item.id, account_id=coa_map["1000"],
                    project_code_id=proj_map.get(pcode),
                    description=f"Stock issue {code}", narration="Kano outreach", debit=0, credit=issue_total, created_by=program.id,
                ))
        db.commit()

        # ---- Procurement: CONTRAconnect-aligned robust LTA (Lot 1 FP + Lot 2 Consumables) ----
        cm = db.query(ProcurementCommittee).filter(ProcurementCommittee.company_id == demo.id).first()
        if not cm:
            cm = ProcurementCommittee(company_id=demo.id, name="CONTRAconnect Evaluation Committee",
                description="Pass/Fail technical then lowest-price among compliant bids (per TOR evaluation methodology)")
            db.add(cm); db.flush()
            for mn, rt in [("Dr. Ada Okoro", "Chair"), ("Engr. Bello Yusuf", "Member"), ("Pharm. Chidi Eze", "Secretary")]:
                db.add(ProcurementCommitteeMember(committee_id=cm.id, member_name=mn, role_title=rt))
            db.flush()
        members = db.query(ProcurementCommitteeMember).filter(ProcurementCommitteeMember.committee_id == cm.id).all()

        svc_map = {}
        for sc, sn in [("PROC-FP", "Family Planning Commodities Lot 1"), ("PROC-MEDC", "Medical Consumables Lot 2"), ("PROC-IT", "IT equipment")]:
            s = db.query(ProcurementService).filter(ProcurementService.company_id == demo.id, ProcurementService.code == sc).first()
            if not s:
                s = ProcurementService(company_id=demo.id, code=sc, name=sn, description=sn)
                db.add(s); db.flush()
            svc_map[sc] = s.id

        # Ensure prequalified vendors with eligibility fields
        vmap = {}
        vendor_defs = [
            ("V-FP01", "PharmaLink Nigeria Ltd", 5, 3, "valid", "Valid NAFDAC & MAF", True, True, True),
            ("V-FP02", "MediCare Distributors", 4, 2, "valid", "NAFDAC listed", True, False, True),
            ("V-MED01", "SafeHealth Consumables Ltd", 6, 4, "valid", "PCN + NAFDAC", True, True, True),
            ("V-001", "MedSupply Co", 3, 2, "valid", "Legacy demo", False, False, True),
            ("V-002", "TechMart Nigeria", 2, 1, "pending", "", False, False, True),
            ("V-003", "Training Hub Ltd", 4, 2, "n/a", "", False, False, True),
        ]
        for vn, name, yrs, sims, naf, logi, iso, pcn, demoflag in vendor_defs:
            v = db.query(Vendor).filter(Vendor.company_id == demo.id, Vendor.vendor_number == vn).first()
            if not v:
                v = Vendor(company_id=demo.id, vendor_number=vn, name=name,
                    experience_years=yrs, similar_contracts_count=sims, nafdac_status=naf,
                    logistics_footprint=logi or "Warehouse + delivery to Benin City",
                    iso_13485=iso, cgm_p=pcn, is_prequalified=(yrs >= 3 and sims >= 2),
                    eligibility_status="eligible" if (yrs >= 3 and sims >= 2) else "pending",
                    is_demo=demoflag, address="Lagos / Benin City", tax_clearance="valid 2024-2026")
                db.add(v); db.flush()
            vmap[vn] = v

        def ensure_rfq(rfq_no, title, svc, status, pcode, debit, credit, lot="", specs="", shelf=6):
            r = db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == demo.id, ProcurementRFQ.rfq_no == rfq_no).first()
            if r:
                return r
            r = ProcurementRFQ(
                company_id=demo.id, rfq_no=rfq_no, title=title, lot=lot,
                service_id=svc_map.get(svc), committee_id=cm.id,
                description=title, technical_specs=specs, status=status,
                evaluation_method="lowest_price_technically_compliant",
                delivery_location="Benin City central store, Egor LGA, Edo State",
                min_shelf_life_months=shelf, is_lta=True, lta_duration_months=18,
                requesting_officer_id=program.id, created_by=program.id,
                debit_account_id=coa_map.get(debit), credit_account_id=coa_map.get(credit),
                project_code_id=proj_map.get(pcode), is_demo=True,
            )
            db.add(r); db.flush()
            return r

        # LOT 1 — Family Planning Commodities (Tranche 1 Pilot quantities from TOR Annex 1A)
        specs_fp = "Implanon 209 ctn; Jadelle 10 ctn; Injectables 30 ctn; IUCD 2 ctn; Microgynon 50 ctn; Male condoms 8 ctn. Remaining shelf life ≥6 months. MAF, SOP recall, storage guidance required."
        rfq_fp = ensure_rfq("RFQ-FP-LOT1", "LTA Lot 1: Procurement & Supply of Family Planning Commodities (CONTRAconnect Pilot)",
            "PROC-FP", "technical_eval", "PRJ-HLT", "5500", "2000", lot="Lot 1 FP Commodities", specs=specs_fp, shelf=6)
        if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_fp.id).first():
            q_fp1 = ProcurementQuote(company_id=demo.id, rfq_id=rfq_fp.id, vendor_id=vmap["V-FP01"].id,
                vendor_name="PharmaLink Nigeria Ltd", amount=18500000, tax_amount=1387500, total_amount=19887500,
                delivery_days=21, lead_time_weeks_larc=12, lead_time_weeks_other=6,
                preliminary_pass=True, technical_pass=True, technical_score=95,
                shelf_life_commitment=True, manufacturer_auth=True, mandatory_docs_complete=True,
                system_score=38, committee_score=55, final_score=93, status="technical", is_demo=True)
            q_fp2 = ProcurementQuote(company_id=demo.id, rfq_id=rfq_fp.id, vendor_id=vmap["V-FP02"].id,
                vendor_name="MediCare Distributors", amount=19200000, tax_amount=1440000, total_amount=20640000,
                delivery_days=28, lead_time_weeks_larc=14, lead_time_weeks_other=8,
                preliminary_pass=True, technical_pass=True, technical_score=88,
                shelf_life_commitment=True, manufacturer_auth=True, mandatory_docs_complete=True,
                system_score=32, committee_score=50, final_score=82, status="technical", is_demo=True)
            q_fp3 = ProcurementQuote(company_id=demo.id, rfq_id=rfq_fp.id, vendor_name="QuickMed Imports",
                amount=17000000, tax_amount=1275000, total_amount=18275000, delivery_days=45,
                preliminary_pass=False, technical_pass=False, mandatory_docs_complete=False,
                shelf_life_commitment=False, manufacturer_auth=False, status="rejected",
                notes="Failed preliminary: missing MAF and NAFDAC proof", is_demo=True)
            db.add_all([q_fp1, q_fp2, q_fp3]); db.flush()
            if members:
                for m in members:
                    db.add(QuoteMemberScore(quote_id=q_fp1.id, member_id=m.id, score=54 + (m.id % 3), comment="Strong FP experience & docs"))
                    db.add(QuoteMemberScore(quote_id=q_fp2.id, member_id=m.id, score=48 + (m.id % 2), comment="Compliant, higher price"))

        # LOT 2 — Medical Consumables (Annex 1 Pilot)
        specs_med = "Gloves latex/surgical, syringes, needles 21G, pregnancy tests, iodine, xylocaine, ABHR, disinfectant, cotton wool, sharps bins etc. NAFDAC, ISO 13485, PCN for Lot2 pharma. Shelf-life ≥75% or 24 months."
        rfq_med = ensure_rfq("RFQ-MED-LOT2", "LTA Lot 2: Supply of Medical Consumables & IPC for CONTRAconnect",
            "PROC-MEDC", "open", "PRJ-HLT", "5500", "2000", lot="Lot 2 Medical Consumables", specs=specs_med, shelf=24)
        if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_med.id).first():
            db.add(ProcurementQuote(company_id=demo.id, rfq_id=rfq_med.id, vendor_id=vmap["V-MED01"].id,
                vendor_name="SafeHealth Consumables Ltd", amount=4200000, tax_amount=315000, total_amount=4515000,
                delivery_days=10, preliminary_pass=True, technical_pass=False, mandatory_docs_complete=True,
                shelf_life_commitment=True, manufacturer_auth=True, status="submitted", is_demo=True))

        # Legacy open RFQ retained for compatibility
        rfq_open = ensure_rfq("RFQ-0001", "ORS and first-aid kits for outreach", "PROC-MEDC", "open", "PRJ-HLT", "5500", "2000")
        if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_open.id).first():
            db.add(ProcurementQuote(company_id=demo.id, rfq_id=rfq_open.id,
                vendor_id=vmap.get("V-001").id if vmap.get("V-001") else None,
                vendor_name="MedSupply Co", amount=980000, tax_amount=73500, total_amount=1053500,
                delivery_days=14, notes="Includes delivery to Benin City", system_score=40, status="submitted", is_demo=True))

        # Awarded + PO + GRN + Invoice flow to Finance (demo of full cycle)
        rfq_aw = ensure_rfq("RFQ-0003", "Project laptops for field teams", "PROC-IT", "awarded", "PRJ-CAP", "1510", "2000")
        q_win = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_aw.id, ProcurementQuote.status == "winner").first()
        if not q_win:
            q_win = ProcurementQuote(company_id=demo.id, rfq_id=rfq_aw.id,
                vendor_id=vmap.get("V-002").id if vmap.get("V-002") else None,
                vendor_name="TechMart Nigeria", amount=2400000, tax_amount=180000, total_amount=2580000,
                delivery_days=21, preliminary_pass=True, technical_pass=True, system_score=40, committee_score=52, final_score=92,
                status="winner", mandatory_docs_complete=True, is_demo=True)
            q_lose = ProcurementQuote(company_id=demo.id, rfq_id=rfq_aw.id, vendor_name="ByteStore Ltd",
                amount=2650000, tax_amount=198750, total_amount=2848750, delivery_days=28,
                preliminary_pass=True, technical_pass=True, system_score=28, committee_score=45, final_score=73,
                status="rejected", is_demo=True)
            db.add_all([q_win, q_lose]); db.flush()
            if members:
                for m in members:
                    db.add(QuoteMemberScore(quote_id=q_win.id, member_id=m.id, score=50, comment="Best value"))
        po = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == demo.id, PurchaseOrder.po_no == "PO-0001").first()
        if not po and q_win:
            po = PurchaseOrder(company_id=demo.id, po_no="PO-0001", rfq_id=rfq_aw.id, quote_id=q_win.id,
                vendor_id=q_win.vendor_id, vendor_name=q_win.vendor_name, amount=q_win.total_amount,
                description=rfq_aw.title, status="pending_officer", requesting_officer_id=program.id,
                debit_account_id=coa_map.get("1510"), credit_account_id=coa_map.get("2000"),
                project_code_id=proj_map.get("PRJ-CAP"), approved_at=datetime.utcnow() - _td(days=1), created_by=finance.id)
            db.add(po); db.flush()

        # Goods Receipt with all conditions met (demo)
        if po and not db.query(GoodsReceipt).filter(GoodsReceipt.po_id == po.id).first():
            grn = GoodsReceipt(company_id=demo.id, po_id=po.id, grn_no="GRN-0001",
                received_by="Store Officer – Benin City", quantities_ok=True, package_integrity_ok=True,
                shelf_life_ok=True, regulatory_docs_ok=True, storage_guidance_received=True,
                all_conditions_met=True, status="accepted", accepted_by_user_id=program.id,
                accepted_at=datetime.utcnow() - _td(days=1), is_demo=True)
            db.add(grn); db.flush()
            # Invoice flows to Finance
            inv = ProcurementInvoice(company_id=demo.id, po_id=po.id, grn_id=grn.id,
                invoice_no="INV-TM-88421", amount=2400000, tax_amount=180000, total_amount=2580000,
                status="approved_for_payment", submitted_to_finance_at=datetime.utcnow() - _td(hours=12), is_demo=True)
            db.add(inv)

        # Second PO already in payment workflow
        rfq_pay = ensure_rfq("RFQ-0004", "Office furniture top-up", "PROC-IT", "awarded", "PRJ-OPS", "1500", "2000")
        qf = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_pay.id).first()
        if not qf:
            qf = ProcurementQuote(company_id=demo.id, rfq_id=rfq_pay.id, vendor_name="Property Holdings Ltd",
                amount=600000, tax_amount=45000, total_amount=645000, delivery_days=14,
                preliminary_pass=True, technical_pass=True, system_score=40, committee_score=50, final_score=90,
                status="winner", mandatory_docs_complete=True, is_demo=True)
            db.add(qf); db.flush()
        po2 = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == demo.id, PurchaseOrder.po_no == "PO-0002").first()
        if not po2:
            po2 = PurchaseOrder(company_id=demo.id, po_no="PO-0002", rfq_id=rfq_pay.id, quote_id=qf.id,
                vendor_name=qf.vendor_name, amount=qf.total_amount, description=rfq_pay.title,
                status="submitted_payment", requesting_officer_id=program.id,
                debit_account_id=coa_map.get("1500"), credit_account_id=coa_map.get("2000"),
                project_code_id=proj_map.get("PRJ-OPS"), created_by=finance.id)
            db.add(po2)

        print("✅ Demo seeded: projects, inventory postings, procurement (open / evaluation / PO pending / payment in workflow)")

        # Second company still pending approval (for superadmin demo)
        pending = db.query(Company).filter(Company.slug == "sunrise-ngo").first()
        if not pending:
            pending = Company(
                name="Sunrise Community NGO",
                slug="sunrise-ngo",
                address="Abuja, FCT",
                status="pending",
            )
            db.add(pending)
            db.commit()
            db.refresh(pending)
            db.add(User(
                company_id=pending.id,
                username="admin",
                email="admin@sunrise.ngo",
                full_name="Sunrise Admin",
                hashed_password=get_password_hash("Sunrise@Admin2026!"),
                role="company_admin",
                is_active=True,
                can_access_finance=True,
                can_access_inventory=True,
                can_access_assets=True,
                can_edit_assets=True,
                can_access_vendors=True,
                can_access_reports=True,
                can_approve_payment=True,
            ))
            db.commit()
            print("✅ Pending sample firm: sunrise-ngo (awaits superadmin approval)")

        print("✅ Demo company approved + licensed | admin / Admin@FMSS2026!")



def ensure_demo_core_finance(db: Session):
    """If demo company exists but has no COA/payments, seed core finance data."""
    from datetime import timedelta as _td
    demo = db.query(Company).filter(Company.slug == "demo").first()
    if not demo:
        demo = Company(
            name="Demo Organization", slug="demo", address="Lagos, Nigeria",
            status="approved", license_key=generate_license_key("demo"),
            license_expires=date.today() + timedelta(days=365),
            approved_at=datetime.utcnow(), approved_by="system",
        )
        db.add(demo); db.commit(); db.refresh(demo)
        print("Created missing demo company")
    else:
        demo.status = "approved"
        if not demo.license_expires or demo.license_expires < date.today():
            demo.license_expires = date.today() + timedelta(days=365)
        if not demo.license_key:
            demo.license_key = generate_license_key("demo")
        db.add(demo); db.commit()
    # Ensure users
    users = {}
    for uname, role, pwd, email, perms in [
        ("admin", "company_admin", "Admin@FMSS2026!", "admin@demo.local", True),
        ("finance", "finance", "Finance@FMSS2026!", "finance@demo.local", True),
        ("program", "program", "Program@FMSS2026!", "program@demo.local", True),
    ]:
        u = db.query(User).filter(User.company_id == demo.id, User.username == uname).first()
        if not u:
            u = User(
                company_id=demo.id, username=uname, email=email, full_name=uname.title(),
                hashed_password=get_password_hash(pwd), role=role, is_active=True,
                can_access_finance=True, can_access_inventory=True, can_access_assets=True,
                can_edit_assets=True, can_access_vendors=True, can_access_reports=True,
                can_approve_payment=True,
            )
            db.add(u); db.flush()
        else:
            u.hashed_password = get_password_hash(pwd)
            u.is_active = True
            db.add(u)
        users[uname] = u
    db.commit()
    admin, finance, program = users["admin"], users["finance"], users["program"]

    coa_count = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == demo.id).count()
    if coa_count == 0:
        print("Seeding core COA for demo…")
        coa_rows = [
            ("1000", "Cash at Bank - Main", "Cash"),
            ("1100", "Petty Cash", "Cash"),
            ("1200", "Accounts Receivable", "Asset"),
            ("1500", "Furniture & Fittings", "Asset"),
            ("1510", "IT Equipment", "Asset"),
            ("1520", "Motor Vehicles", "Asset"),
            ("2000", "Accounts Payable", "Liability"),
            ("3000", "Retained Earnings", "Equity"),
            ("4000", "Grant Income", "Income"),
            ("4100", "Other Income", "Income"),
            ("5000", "Staff Salaries", "Expense"),
            ("5100", "Office Rent", "Expense"),
            ("5200", "Travel & Transport", "Expense"),
            ("5300", "Training & Workshops", "Expense"),
            ("5400", "Utilities & Communications", "Expense"),
            ("5500", "Programme Supplies", "Expense"),
            ("5600", "Professional Fees", "Expense"),
            ("5700", "Bank Charges", "Expense"),
        ]
        coa_map = {}
        for code, name, typ in coa_rows:
            row = ChartOfAccount(company_id=demo.id, code=code, name=name, account_type=typ)
            db.add(row); db.flush()
            coa_map[code] = row.id
        db.commit()
    else:
        coa_map = {a.code: a.id for a in db.query(ChartOfAccount).filter(ChartOfAccount.company_id == demo.id).all()}

    if db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).count() == 0:
        budgets = [
            ("BUD-HEALTH-2026", "Health Programme 2026", 25000000, program.id),
            ("BUD-EDU-2026", "Education Support 2026", 18000000, program.id),
            ("BUD-OPS-2026", "Operations & Admin 2026", 8000000, finance.id),
            ("BUD-CAPEX-2026", "Capital Expenditure 2026", 12000000, admin.id),
        ]
        for code, desc, amt, approver in budgets:
            db.add(BudgetCode(company_id=demo.id, code=code, description=desc, amount=amt, spent=0, default_approver_id=approver))
        db.commit()

    bud_map = {b.code: b.id for b in db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).all()}

    if db.query(ExpenseCode).filter(ExpenseCode.company_id == demo.id).count() == 0 and bud_map:
        expenses = [
            ("EXP-SAL", "Monthly staff salaries", bud_map.get("BUD-OPS-2026"), coa_map.get("5000"), coa_map.get("1000")),
            ("EXP-RENT", "Office rent payment", bud_map.get("BUD-OPS-2026"), coa_map.get("5100"), coa_map.get("1000")),
            ("EXP-TRV", "Field travel allowances", bud_map.get("BUD-HEALTH-2026"), coa_map.get("5200"), coa_map.get("1000")),
            ("EXP-TRN", "Community training workshop", bud_map.get("BUD-EDU-2026"), coa_map.get("5300"), coa_map.get("1000")),
            ("EXP-SUP", "Medical supplies for outreach", bud_map.get("BUD-HEALTH-2026"), coa_map.get("5500"), coa_map.get("1000")),
            ("EXP-IT", "Laptops and peripherals", bud_map.get("BUD-CAPEX-2026"), coa_map.get("1510"), coa_map.get("1000")),
        ]
        for code, desc, bid, dr, cr in expenses:
            if bid:
                db.add(ExpenseCode(
                    company_id=demo.id, code=code, description=desc, budget_code_id=bid,
                    default_debit_account_id=dr, default_credit_account_id=cr,
                ))
        db.commit()

    exp_list = db.query(ExpenseCode).filter(ExpenseCode.company_id == demo.id).all()
    bud_list = db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).all()

    if db.query(PaymentRequest).filter(PaymentRequest.company_id == demo.id).count() < 3 and exp_list and bud_list:
        print("Seeding sample payment requests…")
        samples = [
            ("PR-0001", 850000, "Office rent Q1", "Property Holdings Ltd", "paid", program.id, finance.id),
            ("PR-0002", 4200000, "March payroll", "Staff Payroll Account", "paid", program.id, finance.id),
            ("PR-0003", 1250000, "Project laptops", "TechMart Nigeria", "finance_approved", program.id, finance.id),
            ("PR-0004", 320000, "Training workshop", "Training Hub Ltd", "program_approved", program.id, None),
            ("PR-0005", 175000, "Field travel", "Cash advance", "submitted", program.id, None),
        ]
        for i, (rno, amt, narr, payee, status, prog, fin) in enumerate(samples):
            exp = exp_list[i % len(exp_list)]
            pr = PaymentRequest(
                company_id=demo.id, request_no=rno, requester_id=program.id,
                budget_code_id=exp.budget_code_id, expense_code_id=exp.id,
                amount=amt, amount_in_words=amount_to_words(amt),
                narration=narr, payee_name=payee,
                debit_account_id=exp.default_debit_account_id, credit_account_id=exp.default_credit_account_id,
                designated_approver_id=program.id, status=status,
                program_approved_by=prog if status != "submitted" else None,
                program_approved_at=datetime.utcnow() - timedelta(days=2) if status != "submitted" else None,
                finance_approved_by=fin if status in ("finance_approved", "paid") else None,
                finance_approved_at=datetime.utcnow() - timedelta(days=1) if status in ("finance_approved", "paid") else None,
                paid_at=datetime.utcnow() - timedelta(hours=12) if status == "paid" else None,
            )
            db.add(pr)
        db.commit()

    if db.query(Vendor).filter(Vendor.company_id == demo.id).count() == 0:
        for num, name, bank, amt, desc in [
            ("V-001", "MedSupply Co", "Zenith Bank", 5000000, "Medical supplies"),
            ("V-002", "TechMart Nigeria", "GTBank", 2750000, "IT equipment"),
            ("V-003", "Training Hub Ltd", "Access Bank", 980000, "Training services"),
            ("V-004", "Property Holdings Ltd", "UBA", 850000, "Office rent"),
        ]:
            db.add(Vendor(
                company_id=demo.id, vendor_number=num, name=name, bank=bank, amount=amt,
                description=desc, tax_clearance="Yes", reg_with_govt="Yes", audit_3yrs="Yes",
                score=90, debit_account_id=coa_map.get("5600"), credit_account_id=coa_map.get("2000"),
            ))
        db.commit()

    if db.query(Asset).filter(Asset.company_id == demo.id).count() == 0:
        for num, name, cat, cost in [
            ("AST-001", "Toyota Hilux", "Vehicle", 18000000),
            ("AST-002", "Dell Server", "IT", 2500000),
            ("AST-003", "Office desks set", "Furniture", 900000),
        ]:
            db.add(Asset(
                company_id=demo.id, asset_number=num, asset_name=name, category=cat,
                cost=cost, nbv=cost * 0.8, condition="Good", status="active",
                debit_account_id=coa_map.get("1510"), credit_account_id=coa_map.get("1000"),
                created_by=admin.id,
            ))
        db.commit()

    print("✅ ensure_demo_core_finance done (COA/budgets/expenses/payments/vendors/assets)")



def ensure_demo_extended_samples(db: Session):
    """Idempotent: fill projects, inventory JE, procurement stages for demo company."""
    demo = db.query(Company).filter(Company.slug == "demo").first()
    if not demo:
        return
    finance = db.query(User).filter(User.company_id == demo.id, User.username == "finance").first()
    program = db.query(User).filter(User.company_id == demo.id, User.username == "program").first()
    admin = db.query(User).filter(User.company_id == demo.id, User.username == "admin").first()
    if not finance or not program:
        return
    coa = {a.code: a.id for a in db.query(ChartOfAccount).filter(ChartOfAccount.company_id == demo.id).all()}
    if not coa.get("1000"):
        return

    # Projects
    proj_defs = [
        ("PRJ-HLT", "Health Outreach 2026", 5000000),
        ("PRJ-EDU", "Education Support 2026", 3500000),
        ("PRJ-OPS", "Operations & Admin", 1500000),
        ("PRJ-WASH", "Water & Sanitation", 2800000),
        ("PRJ-CAP", "Capital / Equipment", 4200000),
    ]
    proj_map = {}
    for code, name, bud in proj_defs:
        pc = db.query(ProjectCode).filter(ProjectCode.company_id == demo.id, ProjectCode.code == code).first()
        if not pc:
            kwargs = dict(company_id=demo.id, code=code, name=name, description=name)
            if hasattr(ProjectCode, "budget_amount"):
                kwargs["budget_amount"] = bud
            pc = ProjectCode(**kwargs)
            db.add(pc); db.flush()
        proj_map[code] = pc.id

    # Tag untagged journal lines
    jes = db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.project_code_id.is_(None)).limit(200).all()
    codes = list(proj_map.values())
    for i, j in enumerate(jes):
        j.project_code_id = codes[i % len(codes)]
        db.add(j)

    # Project-coded sample journals
    extra_jes = [
        ("JE-PRJ-HLT-01", "1000", "4000", 2000000, "Grant received — Health", "PRJ-HLT"),
        ("JE-PRJ-HLT-02", "5500", "1000", 450000, "Medical kits — field", "PRJ-HLT"),
        ("JE-PRJ-EDU-01", "1000", "4000", 1500000, "Grant received — Education", "PRJ-EDU"),
        ("JE-PRJ-EDU-02", "5300", "1000", 320000, "Teacher training workshop", "PRJ-EDU"),
        ("JE-PRJ-WASH-01", "5500", "1000", 280000, "Water treatment supplies", "PRJ-WASH"),
        ("JE-PRJ-OPS-01", "5100", "1000", 850000, "HQ rent allocation", "PRJ-OPS"),
        ("JE-PRJ-CAP-01", "1510", "1000", 1250000, "Project laptops", "PRJ-CAP"),
        ("JE-PRJ-HLT-03", "5200", "1000", 175000, "Field travel — outreach", "PRJ-HLT"),
        ("JE-PRJ-EDU-03", "5300", "1000", 210000, "School materials distribution", "PRJ-EDU"),
    ]
    for eno, dr, cr, amt, desc, pcode in extra_jes:
        if eno in [x.entry_no for x in db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.entry_no == eno).limit(1).all()]:
            continue
        if dr not in coa or cr not in coa:
            continue
        pid = proj_map.get(pcode)
        db.add(JournalEntry(company_id=demo.id, entry_no=eno, entry_date=date.today() - timedelta(days=5),
            source_type="manual", account_id=coa[dr], project_code_id=pid,
            description=desc, narration=f"Project {pcode}", debit=amt, credit=0, created_by=finance.id))
        db.add(JournalEntry(company_id=demo.id, entry_no=eno, entry_date=date.today() - timedelta(days=5),
            source_type="manual", account_id=coa[cr], project_code_id=pid,
            description=desc, narration=f"Project {pcode}", debit=0, credit=amt, created_by=finance.id))

    # Inventory items + movements + postings
    inv_samples = [
        ("INV-MED-001", "ORS Sachets (box)", "Medical", 2500, 40, 10, "PRJ-HLT"),
        ("INV-MED-002", "First aid kits", "Medical", 15000, 25, 5, "PRJ-HLT"),
        ("INV-EDU-001", "Exercise books (carton)", "Education", 8000, 30, 8, "PRJ-EDU"),
        ("INV-EDU-002", "Chalk & markers pack", "Education", 3500, 50, 12, "PRJ-EDU"),
        ("INV-WASH-001", "Water purification tabs", "WASH", 1200, 100, 20, "PRJ-WASH"),
        ("INV-OPS-001", "Office stationery kit", "Admin", 4500, 15, 3, "PRJ-OPS"),
    ]
    for code, name, cat, cost, recv, issued, pcode in inv_samples:
        item = db.query(InventoryItem).filter(InventoryItem.company_id == demo.id, InventoryItem.item_code == code).first()
        if not item:
            bal = recv - issued
            item = InventoryItem(
                company_id=demo.id, item_code=code, item_name=name, category=cat,
                cost_price=cost, qty_received=recv, qty_issued=issued, balance_qty=bal,
                total_value=bal * cost, department="Programme",
                debit_account_id=coa.get("5500"), credit_account_id=coa.get("1000"),
                project_code_id=proj_map.get(pcode), funding_source="Grant",
            )
            db.add(item); db.flush()
            # receive movement + JE
            eno = f"JE-INV-RCV-{code}"
            if not db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.entry_no == eno).first():
                total = recv * cost
                db.add(InventoryMovement(
                    company_id=demo.id, item_id=item.id, movement_type="receive",
                    quantity=recv, unit_cost=cost, total=total, narration=f"Opening stock {code}",
                    debit_account_id=coa.get("5500"), credit_account_id=coa.get("1000"),
                    project_code_id=proj_map.get(pcode), created_by=finance.id,
                ))
                db.add(JournalEntry(company_id=demo.id, entry_no=eno, entry_date=date.today() - timedelta(days=10),
                    source_type="inventory", source_id=item.id, account_id=coa["5500"], project_code_id=proj_map.get(pcode),
                    description=f"Stock receive {code}", narration=name, debit=total, credit=0, created_by=finance.id))
                db.add(JournalEntry(company_id=demo.id, entry_no=eno, entry_date=date.today() - timedelta(days=10),
                    source_type="inventory", source_id=item.id, account_id=coa["1000"], project_code_id=proj_map.get(pcode),
                    description=f"Stock receive {code}", narration=name, debit=0, credit=total, created_by=finance.id))
            if issued > 0:
                eno2 = f"JE-INV-ISS-{code}"
                if not db.query(JournalEntry).filter(JournalEntry.company_id == demo.id, JournalEntry.entry_no == eno2).first():
                    itotal = issued * cost
                    db.add(InventoryMovement(
                        company_id=demo.id, item_id=item.id, movement_type="issue",
                        quantity=issued, unit_cost=cost, total=itotal, narration="Field distribution",
                        debit_account_id=coa.get("5500"), credit_account_id=coa.get("1000"),
                        project_code_id=proj_map.get(pcode), created_by=program.id,
                    ))
                    db.add(JournalEntry(company_id=demo.id, entry_no=eno2, entry_date=date.today() - timedelta(days=2),
                        source_type="inventory", source_id=item.id, account_id=coa["5500"], project_code_id=proj_map.get(pcode),
                        description=f"Stock issue {code}", narration="Field distribution", debit=itotal, credit=0, created_by=program.id))
                    db.add(JournalEntry(company_id=demo.id, entry_no=eno2, entry_date=date.today() - timedelta(days=2),
                        source_type="inventory", source_id=item.id, account_id=coa["1000"], project_code_id=proj_map.get(pcode),
                        description=f"Stock issue {code}", narration="Field distribution", debit=0, credit=itotal, created_by=program.id))

    # Committee
    cm = db.query(ProcurementCommittee).filter(ProcurementCommittee.company_id == demo.id).first()
    if not cm:
        cm = ProcurementCommittee(company_id=demo.id, name="Evaluation Committee", description="Default procurement evaluation panel")
        db.add(cm); db.flush()
        for mn, rt in [("Ada Chair", "Chair"), ("Bello Member", "Member"), ("Chidi Secretary", "Secretary")]:
            db.add(ProcurementCommitteeMember(committee_id=cm.id, member_name=mn, role_title=rt))
        db.flush()
    members = db.query(ProcurementCommitteeMember).filter(ProcurementCommitteeMember.committee_id == cm.id).all()

    svc_map = {}
    for sc, sn in [("PROC-MED", "Medical supplies"), ("PROC-IT", "IT equipment"), ("PROC-TRN", "Training services")]:
        s = db.query(ProcurementService).filter(ProcurementService.company_id == demo.id, ProcurementService.code == sc).first()
        if not s:
            s = ProcurementService(company_id=demo.id, code=sc, name=sn, description=sn)
            db.add(s); db.flush()
        svc_map[sc] = s.id

    vmap = {v.vendor_number: v for v in db.query(Vendor).filter(Vendor.company_id == demo.id).all()}

    def ensure_rfq(rfq_no, title, svc, status, pcode, debit, credit):
        r = db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == demo.id, ProcurementRFQ.rfq_no == rfq_no).first()
        if r:
            return r
        r = ProcurementRFQ(
            company_id=demo.id, rfq_no=rfq_no, title=title,
            service_id=svc_map.get(svc), committee_id=cm.id,
            description=title, status=status,
            requesting_officer_id=program.id, created_by=program.id,
            debit_account_id=coa.get(debit), credit_account_id=coa.get(credit),
            project_code_id=proj_map.get(pcode),
        )
        db.add(r); db.flush()
        return r

    # OPEN — incomplete
    rfq_open = ensure_rfq("RFQ-0001", "ORS and first-aid kits for outreach", "PROC-MED", "open", "PRJ-HLT", "5500", "2000")
    if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_open.id).first():
        db.add(ProcurementQuote(
            company_id=demo.id, rfq_id=rfq_open.id,
            vendor_id=vmap["V-001"].id if vmap.get("V-001") else None,
            vendor_name="MedSupply Co", amount=980000, tax_amount=73500, total_amount=1053500,
            delivery_days=14, notes="Includes delivery to Kano", system_score=40, status="submitted",
        ))

    # EVALUATION — in committee scoring, not awarded
    rfq_eval = ensure_rfq("RFQ-0002", "Teacher training venue and materials", "PROC-TRN", "evaluation", "PRJ-EDU", "5300", "2000")
    if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_eval.id).first():
        q1 = ProcurementQuote(
            company_id=demo.id, rfq_id=rfq_eval.id,
            vendor_id=vmap["V-003"].id if vmap.get("V-003") else None,
            vendor_name="Training Hub Ltd", amount=750000, tax_amount=56250, total_amount=806250,
            delivery_days=7, system_score=40, committee_score=48, final_score=88, status="scored",
        )
        q2 = ProcurementQuote(
            company_id=demo.id, rfq_id=rfq_eval.id,
            vendor_name="LearnRight Services", amount=820000, tax_amount=61500, total_amount=881500,
            delivery_days=10, system_score=32, committee_score=42, final_score=74, status="scored",
        )
        db.add_all([q1, q2]); db.flush()
        for m in members:
            db.add(QuoteMemberScore(quote_id=q1.id, member_id=m.id, score=46 + (m.id % 5), comment="Adequate"))
            db.add(QuoteMemberScore(quote_id=q2.id, member_id=m.id, score=40 + (m.id % 4), comment="Higher price"))

    # AWARDED + PO pending officer (not submitted to payment)
    rfq_aw = ensure_rfq("RFQ-0003", "Project laptops for field teams", "PROC-IT", "awarded", "PRJ-CAP", "1510", "2000")
    if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_aw.id).first():
        qw = ProcurementQuote(
            company_id=demo.id, rfq_id=rfq_aw.id,
            vendor_id=vmap["V-002"].id if vmap.get("V-002") else None,
            vendor_name="TechMart Nigeria", amount=2500000, tax_amount=187500, total_amount=2687500,
            delivery_days=21, system_score=40, committee_score=52, final_score=92, status="winner",
        )
        ql = ProcurementQuote(
            company_id=demo.id, rfq_id=rfq_aw.id,
            vendor_name="ByteSoft Ltd", amount=2750000, tax_amount=206250, total_amount=2956250,
            delivery_days=30, system_score=28, committee_score=40, final_score=68, status="rejected",
        )
        db.add_all([qw, ql]); db.flush()
        for m in members:
            db.add(QuoteMemberScore(quote_id=qw.id, member_id=m.id, score=50 + (m.id % 3), comment="Preferred"))
    else:
        qw = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_aw.id, ProcurementQuote.status == "winner").first()
        if not qw:
            qw = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_aw.id).first()

    po1 = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == demo.id, PurchaseOrder.po_no == "PO-0001").first()
    if not po1 and qw:
        db.add(PurchaseOrder(
            company_id=demo.id, po_no="PO-0001", rfq_id=rfq_aw.id, quote_id=qw.id,
            vendor_id=qw.vendor_id, vendor_name=qw.vendor_name or "TechMart Nigeria",
            amount=qw.total_amount or 2687500, description=rfq_aw.title,
            status="pending_officer", requesting_officer_id=program.id,
            debit_account_id=coa.get("1510"), credit_account_id=coa.get("2000"),
            project_code_id=proj_map.get("PRJ-CAP"),
            approved_at=datetime.utcnow() - timedelta(days=1), created_by=finance.id,
        ))

    # AWARDED + PO submitted → payment still in workflow (program_approved, awaiting finance)
    rfq_pay = ensure_rfq("RFQ-0004", "Office furniture top-up", "PROC-IT", "awarded", "PRJ-OPS", "1500", "2000")
    if not db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_pay.id).first():
        qf = ProcurementQuote(
            company_id=demo.id, rfq_id=rfq_pay.id,
            vendor_id=vmap["V-004"].id if vmap.get("V-004") else None,
            vendor_name="Property Holdings Ltd", amount=850000, tax_amount=63750, total_amount=913750,
            delivery_days=14, system_score=40, committee_score=50, final_score=90, status="winner",
        )
        db.add(qf); db.flush()
    else:
        qf = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rfq_pay.id).first()

    po2 = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == demo.id, PurchaseOrder.po_no == "PO-0002").first()
    if not po2 and qf:
        # budget / expense maps
        bud = db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).first()
        exp = db.query(ExpenseCode).filter(ExpenseCode.company_id == demo.id).first()
        if bud and exp:
            pr = PaymentRequest(
                company_id=demo.id, request_no="PR-PO-0002",
                requester_id=program.id, budget_code_id=bud.id, expense_code_id=exp.id,
                project_code_id=proj_map.get("PRJ-OPS"),
                amount=qf.total_amount or 913750,
                amount_in_words=amount_to_words(qf.total_amount or 913750),
                narration="Office furniture top-up from PO-0002", payee_name=qf.vendor_name or "Property Holdings Ltd",
                debit_account_id=coa.get("1500"), credit_account_id=coa.get("2000"),
                designated_approver_id=program.id, status="program_approved",
                program_approved_by=program.id, program_approved_at=datetime.utcnow() - timedelta(hours=6),
            )
            db.add(pr); db.flush()
            db.add(PurchaseOrder(
                company_id=demo.id, po_no="PO-0002", rfq_id=rfq_pay.id, quote_id=qf.id,
                vendor_name=qf.vendor_name, amount=qf.total_amount, description=rfq_pay.title,
                status="submitted_payment", requesting_officer_id=program.id,
                payment_request_id=pr.id,
                debit_account_id=coa.get("1500"), credit_account_id=coa.get("2000"),
                project_code_id=proj_map.get("PRJ-OPS"),
                approved_at=datetime.utcnow() - timedelta(days=2), created_by=finance.id,
            ))
            db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=program.id, action="submit_from_po", comment="From PO-0002"))
            db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=program.id, action="program_approve", comment="Program OK"))

    # Tag sample payments with projects where missing
    pays = db.query(PaymentRequest).filter(PaymentRequest.company_id == demo.id, PaymentRequest.project_code_id.is_(None)).all()
    for i, p in enumerate(pays):
        p.project_code_id = codes[i % len(codes)]
        db.add(p)

    db.commit()
    print("✅ Extended demo samples: projects, inventory JE, procurement open/evaluation/PO pending/payment in workflow")



@app.on_event("startup")
def _app_startup_entry():
    """Single startup entry — always opens its own DB session."""
    db = next(get_db())
    try:
        Base.metadata.create_all(bind=engine)
        try:
            _migrate_schema(engine)
        except Exception as e:
            print("migrate:", e)
        try:
            init_defaults(db)
            try:
                if ensure_general_admin:
                    ensure_general_admin(db)
            except Exception as _ga:
                print("ensure_general_admin:", _ga)
            from erp_ext import seed_erp
            seed_erp(db)
        except Exception as e:
            import traceback; print("init_defaults:", e); traceback.print_exc()
        try:
            ensure_demo_core_finance(db)
        except Exception as e:
            import traceback; print("core finance seed error:", e); traceback.print_exc()
        try:
            ensure_demo_extended_samples(db)
        except Exception as e:
            import traceback; print("extended seed error:", e); traceback.print_exc()
        try:
            demo = db.query(Company).filter(Company.slug == "demo").first()
            if demo:
                for uname, pwd in [
                    ("admin", "Admin@FMSS2026!"),
                    ("finance", "Finance@FMSS2026!"),
                    ("program", "Program@FMSS2026!"),
                ]:
                    u = db.query(User).filter(User.company_id == demo.id, User.username == uname).first()
                    if u:
                        u.hashed_password = get_password_hash(pwd)
                        u.is_active = True
                        db.add(u)
                db.commit()
                print("✅ Demo passwords refreshed")
                n_coa = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == demo.id).count()
                n_pay = db.query(PaymentRequest).filter(PaymentRequest.company_id == demo.id).count()
                n_bud = db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).count()
                print(f"📊 Demo data: COA={n_coa} budgets={n_bud} payments={n_pay}")
                if n_coa < 5 or n_pay < 3 or n_bud < 1:
                    ensure_demo_core_finance(db)
                    ensure_demo_extended_samples(db)
            sa = db.query(User).filter(User.username == "superadmin", User.company_id.is_(None)).first()
            if sa:
                sa.hashed_password = get_password_hash("SuperAdmin@FMSS2026!")
                db.add(sa); db.commit()
        except Exception as e:
            import traceback; print("demo refresh:", e); traceback.print_exc()
        try:
            cleanup_disposed_assets(db)
        except Exception as e:
            print("cleanup:", e)
    except Exception as e:
        import traceback
        print("startup error (app continues):", e)
        traceback.print_exc()
    finally:
        try:
            db.close()
        except Exception:
            pass

# ===================== AUTH =====================
@app.post("/api/auth/register-company")
def register_company(data: CompanyRegister, db: Session = Depends(get_db)):
    slug = data.company_slug.lower().strip()
    if db.query(Company).filter(Company.slug == slug).first():
        raise HTTPException(400, "Company slug already taken")
    company = Company(
        name=data.company_name.strip(),
        slug=slug,
        address=data.address or "",
        status="pending",  # awaits superadmin approval
    )
    db.add(company)
    db.commit()
    db.refresh(company)
    admin = User(
        company_id=company.id,
        username=data.admin_username.strip(),
        email=data.admin_email,
        full_name=data.admin_full_name or data.admin_username,
        hashed_password=get_password_hash(data.admin_password),
        role="company_admin",
        is_active=True,
        can_access_finance=True,
        can_access_inventory=True,
        can_access_assets=True,
        can_edit_assets=True,
        can_access_vendors=True,
        can_access_reports=True,
        can_approve_payment=True,
    )
    db.add(admin)
    db.commit()
    audit(db, company.id, admin, "REGISTER_COMPANY", f"Pending approval: {company.name}")
    try:
        from erp_ext import ErpTask
        from models import ErpTask as TaskRow
        import json
        db.add(TaskRow(
            company_id=company.id,
            task_type="company_approval",
            title=f"Approve {company.name}",
            status="submitted",
            assigned_role="owner",
            payload_json=json.dumps({"slug": company.slug}),
            idempotency_key=f"approve-{company.slug}",
            created_by=admin.username,
        ))
        db.commit()
    except Exception as exc:
        db.rollback()
        print("approval task:", exc)
    return {
        "message": "Registration submitted. The owner must approve this company before sign-in.",
        "company": {"name": company.name, "slug": company.slug, "status": "pending"},
    }


@app.post("/api/auth/login", response_model=Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    raw = form_data.username.strip()
    password = form_data.password
    company = None
    username = raw

    # Platform owner and superadmin (no company)
    if raw in ("owner", "superadmin", "general_admin") or raw.startswith("owner/") or raw.startswith("superadmin/") or raw.startswith("general_admin/"):
        if raw.startswith("owner"):
            username = "owner"
        elif raw.startswith("general_admin") or raw == "general_admin":
            username = "general_admin"
        else:
            username = "superadmin"
        user = db.query(User).filter(User.username == username, User.company_id.is_(None)).first()
        if not user or not verify_password(password, user.hashed_password):
            raise HTTPException(401, "Incorrect username or password")
    else:
        if "/" in raw:
            slug, username = raw.split("/", 1)
            slug, username = slug.strip().lower(), username.strip()
            company = db.query(Company).filter(Company.slug == slug).first()
            if not company:
                raise HTTPException(401, "Invalid company or credentials")
        else:
            candidates = db.query(User).filter(User.username == username, User.is_active == True).all()
            # prefer non-null company
            candidates = [c for c in candidates if c.company_id is not None]
            if len(candidates) == 1:
                user = candidates[0]
                company = db.query(Company).filter(Company.id == user.company_id).first()
            elif len(candidates) > 1:
                raise HTTPException(401, "Multiple companies found. Login as company-slug/username")
            else:
                raise HTTPException(401, "Incorrect username or password")

        if company:
            check_company_license(db, company.id)

        user = db.query(User).filter(
            User.company_id == company.id,
            User.username == username,
            User.is_active == True,
        ).first()
        if not user or not verify_password(password, user.hashed_password):
            raise HTTPException(401, "Incorrect username or password")

    user.last_login = datetime.utcnow()
    db.commit()
    audit(db, user.company_id, user, "LOGIN", f"Login {user.username}")

    token = create_access_token({
        "sub": user.username,
        "role": user.role,
        "company_id": user.company_id,
        "company_slug": company.slug if company else None,
    }, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "company_id": user.company_id,
            "company_name": company.name if company else "Knowsoft Platform",
            "company_slug": company.slug if company else None,
            "must_reset_password": user.must_reset_password,
            "can_access_finance": user.can_access_finance,
            "can_access_inventory": user.can_access_inventory,
            "can_access_assets": user.can_access_assets,
            "can_edit_assets": user.can_edit_assets,
            "can_access_vendors": user.can_access_vendors,
            "can_access_reports": user.can_access_reports,
            "can_approve_payment": user.can_approve_payment,
        },
    }


@app.get("/api/auth/me")
def me(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    company = None
    if current_user.company_id:
        company = db.query(Company).filter(Company.id == current_user.company_id).first()
    return {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "company_id": current_user.company_id,
        "company_name": company.name if company else "Knowsoft Platform",
        "company_slug": company.slug if company else None,
        "must_reset_password": current_user.must_reset_password,
        "can_access_finance": current_user.can_access_finance,
        "can_access_inventory": current_user.can_access_inventory,
        "can_access_assets": current_user.can_access_assets,
        "can_edit_assets": current_user.can_edit_assets,
        "can_access_vendors": current_user.can_access_vendors,
        "can_access_reports": current_user.can_access_reports,
        "can_approve_payment": current_user.can_approve_payment,
    }


@app.post("/api/auth/change-password")
def change_password(
    data: PasswordChange,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    if not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(400, "Current password is incorrect")
    current_user.hashed_password = get_password_hash(data.new_password)
    current_user.must_reset_password = False
    db.commit()
    audit(db, current_user.company_id, current_user, "CHANGE_PASSWORD", "Password changed")
    return {"message": "Password updated successfully"}


@app.post("/api/auth/request-reset")
def request_reset(data: PasswordResetRequest, db: Session = Depends(get_db)):
    q = db.query(User).filter(User.email == data.email)
    if data.company_slug:
        co = db.query(Company).filter(Company.slug == data.company_slug.lower()).first()
        if co:
            q = q.filter(User.company_id == co.id)
    user = q.first()
    # Always return success message (don't leak existence)
    if user:
        token = generate_reset_token()
        db.add(PasswordResetToken(
            user_id=user.id,
            token=token,
            expires_at=datetime.utcnow() + timedelta(hours=2),
        ))
        db.commit()
        # In production: email the token. For demo we return it.
        return {
            "message": "If the account exists, a reset token was issued.",
            "reset_token": token,  # remove in production when email is wired
            "hint": "Use this token with /api/auth/confirm-reset (demo only)",
        }
    return {"message": "If the account exists, a reset token was issued."}


@app.post("/api/auth/confirm-reset")
def confirm_reset(data: PasswordResetConfirm, db: Session = Depends(get_db)):
    row = db.query(PasswordResetToken).filter(
        PasswordResetToken.token == data.token,
        PasswordResetToken.used == False,
        PasswordResetToken.expires_at > datetime.utcnow(),
    ).first()
    if not row:
        raise HTTPException(400, "Invalid or expired reset token")
    user = db.query(User).filter(User.id == row.user_id).first()
    if not user:
        raise HTTPException(400, "User not found")
    user.hashed_password = get_password_hash(data.new_password)
    user.must_reset_password = False
    row.used = True
    db.commit()
    return {"message": "Password has been reset. You can sign in now."}


# ===================== SUPERADMIN =====================
@app.get("/api/superadmin/companies")
def list_all_companies(
    current_user: User = Depends(get_superadmin),
    db: Session = Depends(get_db),
):
    return db.query(Company).order_by(Company.created_at.desc()).all()


@app.post("/api/superadmin/companies/{company_id}/approve")
def approve_company(
    company_id: int,
    current_user: User = Depends(get_superadmin),
    db: Session = Depends(get_db),
):
    co = db.query(Company).filter(Company.id == company_id).first()
    if not co:
        raise HTTPException(404, "Company not found")
    co.status = "approved"
    co.approved_at = datetime.utcnow()
    co.approved_by = current_user.username
    if not co.license_expires:
        co.license_key = generate_license_key(co.slug)
        co.license_expires = date.today() + timedelta(days=365)
    db.commit()
    audit(db, co.id, current_user, "APPROVE_COMPANY", f"Approved {co.name}")
    return {"message": f"{co.name} approved", "license_key": co.license_key, "license_expires": str(co.license_expires)}


@app.post("/api/superadmin/companies/{company_id}/reject")
def reject_company(
    company_id: int,
    current_user: User = Depends(get_superadmin),
    db: Session = Depends(get_db),
):
    co = db.query(Company).filter(Company.id == company_id).first()
    if not co:
        raise HTTPException(404, "Company not found")
    co.status = "rejected"
    db.commit()
    audit(db, co.id, current_user, "REJECT_COMPANY", f"Rejected {co.name}")
    return {"message": "Company rejected"}


@app.post("/api/superadmin/companies/{company_id}/license")
def issue_license(
    company_id: int,
    data: LicenseIssue,
    current_user: User = Depends(get_superadmin),
    db: Session = Depends(get_db),
):
    co = db.query(Company).filter(Company.id == company_id).first()
    if not co:
        raise HTTPException(404, "Company not found")
    if co.status != "approved":
        co.status = "approved"
        co.approved_at = datetime.utcnow()
        co.approved_by = current_user.username
    co.license_key = generate_license_key(co.slug)
    base = co.license_expires if co.license_expires and co.license_expires > date.today() else date.today()
    co.license_expires = base + timedelta(days=365 * data.years)
    co.license_notes = data.notes or ""
    db.commit()
    audit(db, co.id, current_user, "ISSUE_LICENSE", f"{data.years} year(s) until {co.license_expires}")
    return {
        "message": "Annual license issued",
        "license_key": co.license_key,
        "license_expires": str(co.license_expires),
    }


@app.post("/api/superadmin/companies/{company_id}/suspend")
def suspend_company(
    company_id: int,
    current_user: User = Depends(get_superadmin),
    db: Session = Depends(get_db),
):
    co = db.query(Company).filter(Company.id == company_id).first()
    if not co:
        raise HTTPException(404, "Company not found")
    co.status = "suspended"
    db.commit()
    return {"message": "Company suspended"}


# ===================== BACKUP / RESTORE =====================
def _company_export_dict(db: Session, company_id: int) -> dict:
    co = db.query(Company).filter(Company.id == company_id).first()
    users = db.query(User).filter(User.company_id == company_id).all()
    coa = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == company_id).all()
    budgets = db.query(BudgetCode).filter(BudgetCode.company_id == company_id).all()
    expenses = db.query(ExpenseCode).filter(ExpenseCode.company_id == company_id).all()
    payments = db.query(PaymentRequest).filter(PaymentRequest.company_id == company_id).all()
    assets = db.query(Asset).filter(Asset.company_id == company_id).all()

    def row(obj, fields):
        return {f: (getattr(obj, f).isoformat() if hasattr(getattr(obj, f), "isoformat") else getattr(obj, f)) for f in fields}

    return {
        "exported_at": datetime.utcnow().isoformat(),
        "company": row(co, ["id", "name", "slug", "address", "status", "license_key", "license_expires",
                            "reporting_currency_code", "reporting_currency_symbol"]),
        "users": [row(u, ["id", "username", "email", "full_name", "role", "is_active"]) for u in users],
        "chart_of_accounts": [row(a, ["code", "name", "account_type"]) for a in coa],
        "budget_codes": [row(b, ["code", "description", "amount", "spent"]) for b in budgets],
        "expense_codes": [row(e, ["code", "description"]) for e in expenses],
        "payment_requests": [row(p, ["request_no", "amount", "status", "narration", "payee_name", "created_at"]) for p in payments],
        "assets": [row(a, ["asset_number", "asset_name", "category", "location", "cost", "condition", "nbv", "image_path"]) for a in assets],
    }


@app.get("/api/backup/company")
def backup_company(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    if current_user.role not in ("company_admin", "superadmin", "finance"):
        raise HTTPException(403, "Not allowed")
    cid = current_user.company_id
    if not cid:
        raise HTTPException(400, "No company context")
    data = _company_export_dict(db, cid)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("company_backup.json", json.dumps(data, indent=2, default=str))
        # CSV exports
        for name, rows, headers in [
            ("users.csv", data["users"], ["username", "email", "full_name", "role", "is_active"]),
            ("assets.csv", data["assets"], ["asset_number", "asset_name", "category", "cost", "condition", "nbv"]),
            ("payments.csv", data["payment_requests"], ["request_no", "amount", "status", "payee_name", "created_at"]),
        ]:
            si = io.StringIO()
            w = csv.DictWriter(si, fieldnames=headers, extrasaction="ignore")
            w.writeheader()
            for r in rows:
                w.writerow(r)
            zf.writestr(name, si.getvalue())
    buf.seek(0)
    audit(db, cid, current_user, "BACKUP", "Company backup downloaded")
    fname = f"backup_{data['company']['slug']}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.zip"
    return StreamingResponse(buf, media_type="application/zip", headers={"Content-Disposition": f"attachment; filename={fname}"})


@app.get("/api/superadmin/backup/all")
def backup_all_companies(
    current_user: User = Depends(get_superadmin),
    db: Session = Depends(get_db),
):
    companies = db.query(Company).all()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for co in companies:
            data = _company_export_dict(db, co.id)
            zf.writestr(f"{co.slug}/company_backup.json", json.dumps(data, indent=2, default=str))
    buf.seek(0)
    audit(db, None, current_user, "BACKUP_ALL", f"{len(companies)} companies")
    fname = f"knowsoft_all_backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.zip"
    return StreamingResponse(buf, media_type="application/zip", headers={"Content-Disposition": f"attachment; filename={fname}"})


@app.post("/api/backup/restore")
async def restore_company_backup(
    file: UploadFile = File(...),
    current_user: User = Depends(get_company_admin),
    db: Session = Depends(get_db),
):
    """Restore non-destructive extras (COA, budgets, expenses, assets) from JSON backup."""
    if not current_user.company_id:
        raise HTTPException(400, "No company context")
    content = await file.read()
    try:
        if file.filename.endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(content)) as zf:
                raw = zf.read("company_backup.json")
        else:
            raw = content
        data = json.loads(raw)
    except Exception as e:
        raise HTTPException(400, f"Invalid backup file: {e}")

    cid = current_user.company_id
    # Import COA
    for row in data.get("chart_of_accounts", []):
        exists = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == cid, ChartOfAccount.code == row["code"]).first()
        if not exists:
            db.add(ChartOfAccount(company_id=cid, code=row["code"], name=row.get("name", ""), account_type=row.get("account_type", "Expense")))
    for row in data.get("budget_codes", []):
        exists = db.query(BudgetCode).filter(BudgetCode.company_id == cid, BudgetCode.code == row["code"]).first()
        if not exists:
            db.add(BudgetCode(company_id=cid, code=row["code"], description=row.get("description", ""), amount=row.get("amount", 0)))
    for row in data.get("assets", []):
        exists = db.query(Asset).filter(Asset.company_id == cid, Asset.asset_number == row["asset_number"]).first()
        if not exists:
            db.add(Asset(
                company_id=cid,
                asset_number=row["asset_number"],
                asset_name=row.get("asset_name", ""),
                category=row.get("category", ""),
                cost=float(row.get("cost") or 0),
                condition=row.get("condition", "Good"),
                nbv=float(row.get("nbv") or 0),
            ))
    db.commit()
    audit(db, cid, current_user, "RESTORE", f"Restored from {file.filename}")
    return {"message": "Backup data restored (merged non-destructively)"}


# ===================== USERS (company scoped) =====================
@app.get("/api/admin/users", response_model=list[UserOut])
def list_users(current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    """Company admin: users in their firm. Superadmin: all users (or filter company_id)."""
    if current_user.role == "superadmin":
        return db.query(User).order_by(User.company_id, User.id).all()
    if not current_user.company_id:
        raise HTTPException(400, "No company context")
    return db.query(User).filter(User.company_id == current_user.company_id).order_by(User.id).all()


@app.get("/api/superadmin/users", response_model=list[UserOut])
def superadmin_list_users(current_user: User = Depends(get_superadmin), db: Session = Depends(get_db)):
    return db.query(User).order_by(User.company_id, User.id).all()


@app.post("/api/superadmin/reseed-demo")
def reseed_demo(current_user: User = Depends(get_superadmin), db: Session = Depends(get_db)):
    """Wipe demo transactional samples and reload finance masters + sample data."""
    demo = db.query(Company).filter(Company.slug == "demo").first()
    if not demo:
        init_defaults(db)
        demo = db.query(Company).filter(Company.slug == "demo").first()
    if not demo:
        raise HTTPException(500, "Could not create demo company")
    # delete child data for clean seed
    try:
        pay_ids = [p.id for p in db.query(PaymentRequest).filter(PaymentRequest.company_id == demo.id).all()]
        if pay_ids:
            db.query(PaymentApprovalLog).filter(PaymentApprovalLog.payment_request_id.in_(pay_ids)).delete(synchronize_session=False)
            db.query(PaymentAttachment).filter(PaymentAttachment.payment_request_id.in_(pay_ids)).delete(synchronize_session=False)
        db.query(PaymentRequest).filter(PaymentRequest.company_id == demo.id).delete(synchronize_session=False)
        db.query(JournalEntry).filter(JournalEntry.company_id == demo.id).delete(synchronize_session=False)
        inv_ids = [i.id for i in db.query(InventoryItem).filter(InventoryItem.company_id == demo.id).all()]
        if inv_ids:
            db.query(InventoryMovement).filter(InventoryMovement.item_id.in_(inv_ids)).delete(synchronize_session=False)
        db.query(InventoryItem).filter(InventoryItem.company_id == demo.id).delete(synchronize_session=False)
        rfq_ids = [r.id for r in db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == demo.id).all()]
        if rfq_ids:
            qids = [q.id for q in db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id.in_(rfq_ids)).all()]
            if qids:
                db.query(QuoteMemberScore).filter(QuoteMemberScore.quote_id.in_(qids)).delete(synchronize_session=False)
            db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id.in_(rfq_ids)).delete(synchronize_session=False)
            db.query(ProcurementDocument).filter(ProcurementDocument.rfq_id.in_(rfq_ids)).delete(synchronize_session=False)
        db.query(PurchaseOrder).filter(PurchaseOrder.company_id == demo.id).delete(synchronize_session=False)
        db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == demo.id).delete(synchronize_session=False)
        db.query(ExpenseCode).filter(ExpenseCode.company_id == demo.id).delete(synchronize_session=False)
        db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).delete(synchronize_session=False)
        db.query(ChartOfAccount).filter(ChartOfAccount.company_id == demo.id).delete(synchronize_session=False)
        db.query(Vendor).filter(Vendor.company_id == demo.id).delete(synchronize_session=False)
        db.query(Asset).filter(Asset.company_id == demo.id).delete(synchronize_session=False)
        db.commit()
    except Exception as e:
        db.rollback()
        print("wipe demo data:", e)
        import traceback; traceback.print_exc()
    ensure_demo_core_finance(db)
    ensure_demo_extended_samples(db)
    n = {
        "coa": db.query(ChartOfAccount).filter(ChartOfAccount.company_id == demo.id).count(),
        "budgets": db.query(BudgetCode).filter(BudgetCode.company_id == demo.id).count(),
        "expenses": db.query(ExpenseCode).filter(ExpenseCode.company_id == demo.id).count(),
        "payments": db.query(PaymentRequest).filter(PaymentRequest.company_id == demo.id).count(),
        "projects": db.query(ProjectCode).filter(ProjectCode.company_id == demo.id).count(),
        "inventory": db.query(InventoryItem).filter(InventoryItem.company_id == demo.id).count(),
    }
    return {"ok": True, "message": "Demo company reseeded", "counts": n}




@app.get("/api/admin/approvers")
def list_approvers(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Users who can approve payment requests in this company."""
    return db.query(User).filter(
        User.company_id == current_user.company_id,
        User.is_active == True,
        User.can_approve_payment == True,
    ).all()


@app.post("/api/admin/users", response_model=UserOut)
def create_user(user_in: UserCreate, current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    if current_user.role == "superadmin" and not current_user.company_id:
        raise HTTPException(400, "Superadmin: manage users from a company context, or use company admin login")
    if db.query(User).filter(User.company_id == current_user.company_id, User.username == user_in.username).first():
        raise HTTPException(400, "Username already exists in your company")
    role = user_in.role if user_in.role in (
        "company_admin", "finance", "program", "project_manager", "asset_editor", "user"
    ) else "user"
    db_user = User(
        company_id=current_user.company_id,
        username=user_in.username,
        email=user_in.email,
        full_name=user_in.full_name,
        hashed_password=get_password_hash(user_in.password),
        role=role,
        is_active=user_in.is_active,
        can_access_finance=user_in.can_access_finance,
        can_access_inventory=user_in.can_access_inventory,
        can_access_assets=user_in.can_access_assets,
        can_edit_assets=user_in.can_edit_assets or role in ("finance", "project_manager", "asset_editor", "company_admin"),
        can_access_vendors=user_in.can_access_vendors,
        can_access_reports=user_in.can_access_reports,
        can_approve_payment=user_in.can_approve_payment or role in ("finance", "program", "project_manager", "company_admin"),
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@app.put("/api/admin/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, user_in: UserUpdate, current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.id == user_id, User.company_id == current_user.company_id).first()
    if not db_user:
        raise HTTPException(404, "User not found")
    for field, value in user_in.dict(exclude_unset=True).items():
        if field == "password" and value:
            db_user.hashed_password = get_password_hash(value)
        elif field != "password":
            setattr(db_user, field, value)
    db.commit()
    db.refresh(db_user)
    return db_user


@app.delete("/api/admin/users/{user_id}")
def delete_user(user_id: int, current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.id == user_id, User.company_id == current_user.company_id).first()
    if not db_user:
        raise HTTPException(404, "User not found")
    if db_user.id == current_user.id:
        raise HTTPException(400, "Cannot delete yourself")
    db.delete(db_user)
    db.commit()
    return {"message": "User deleted"}


# ===================== COMPANY SETTINGS =====================
@app.get("/api/company", response_model=CompanyOut)
def get_company(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not current_user.company_id:
        raise HTTPException(400, "No company")
    return db.query(Company).filter(Company.id == current_user.company_id).first()


@app.put("/api/company", response_model=CompanyOut)
def update_company(data: CompanyUpdate, current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    co = db.query(Company).filter(Company.id == current_user.company_id).first()
    for f, v in data.dict(exclude_unset=True).items():
        setattr(co, f, v)
    db.commit()
    db.refresh(co)
    return co


@app.post("/api/company/upload-logo")
async def upload_logo(file: UploadFile = File(...), current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_IMAGE:
        raise HTTPException(400, "Only image files allowed")
    fname = f"company_{current_user.company_id}_logo{ext}"
    dest = IMAGES_DIR / fname
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)
    co = db.query(Company).filter(Company.id == current_user.company_id).first()
    co.logo_path = f"/static/images/{fname}"
    db.commit()
    return {"logo_path": co.logo_path}


@app.post("/api/company/upload-favicon")
async def upload_favicon(file: UploadFile = File(...), current_user: User = Depends(get_company_admin), db: Session = Depends(get_db)):
    ext = Path(file.filename or "").suffix.lower() or ".png"
    if ext not in ALLOWED_IMAGE | {".ico"}:
        raise HTTPException(400, "Invalid icon file")
    fname = f"company_{current_user.company_id}_favicon{ext}"
    dest = IMAGES_DIR / fname
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)
    co = db.query(Company).filter(Company.id == current_user.company_id).first()
    co.favicon_path = f"/static/images/{fname}"
    db.commit()
    return {"favicon_path": co.favicon_path}


@app.get("/api/settings", response_model=CompanySettingsOut)
def public_settings(db: Session = Depends(get_db)):
    s = db.query(CompanySettings).first()
    return s or CompanySettingsOut(org_name="Knowsoft FMSS ERP", logo_path="/static/images/logo.png", favicon_path="/static/images/favicon.ico")


# ===================== FINANCE MASTERS =====================
@app.get("/api/coa")
@app.get("/api/finance/coa")
def list_coa(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not current_user.company_id:
        return []
    rows = db.query(ChartOfAccount).filter(
        ChartOfAccount.company_id == current_user.company_id, ChartOfAccount.is_active == True
    ).order_by(ChartOfAccount.code).all()
    return [{
        "id": a.id, "code": a.code, "name": a.name, "account_type": a.account_type,
        "project_code": getattr(a, "project_code", "") or "",
        "label": f"{a.code} — {a.name}",
        "is_active": a.is_active,
    } for a in rows]


@app.post("/api/finance/coa")
def create_coa(data: COAIn, current_user: User = Depends(require_roles("finance", "company_admin")), db: Session = Depends(get_db)):
    row = ChartOfAccount(
        company_id=current_user.company_id, code=data.code, name=data.name,
        account_type=data.account_type, project_code=getattr(data, "project_code", "") or "",
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@app.get("/api/finance/budget-codes")
def list_budgets(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    return db.query(BudgetCode).filter(BudgetCode.company_id == current_user.company_id, BudgetCode.is_active == True).all()


@app.post("/api/finance/budget-codes")
def create_budget(data: BudgetCodeIn, current_user: User = Depends(require_roles("finance", "company_admin")), db: Session = Depends(get_db)):
    row = BudgetCode(
        company_id=current_user.company_id,
        code=data.code,
        description=data.description,
        amount=data.amount,
        default_approver_id=data.default_approver_id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@app.get("/api/finance/expense-codes")
def list_expenses(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(ExpenseCode).filter(ExpenseCode.company_id == current_user.company_id, ExpenseCode.is_active == True).all()
    result = []
    for e in rows:
        debit = db.query(ChartOfAccount).filter(ChartOfAccount.id == e.default_debit_account_id).first() if e.default_debit_account_id else None
        credit = db.query(ChartOfAccount).filter(ChartOfAccount.id == e.default_credit_account_id).first() if e.default_credit_account_id else None
        result.append({
            "id": e.id, "code": e.code, "description": e.description,
            "budget_code_id": e.budget_code_id,
            "default_debit_account_id": e.default_debit_account_id,
            "default_credit_account_id": e.default_credit_account_id,
            "default_debit_label": f"{debit.code} - {debit.name}" if debit else None,
            "default_credit_label": f"{credit.code} - {credit.name}" if credit else None,
        })
    return result


@app.post("/api/finance/expense-codes")
def create_expense(data: ExpenseCodeIn, current_user: User = Depends(require_roles("finance", "company_admin")), db: Session = Depends(get_db)):
    row = ExpenseCode(
        company_id=current_user.company_id,
        code=data.code,
        description=data.description,
        budget_code_id=data.budget_code_id,
        default_debit_account_id=data.default_debit_account_id,
        default_credit_account_id=data.default_credit_account_id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


# ===================== PAYMENT REQUESTS =====================
def next_request_no(db, company_id):
    n = db.query(PaymentRequest).filter(PaymentRequest.company_id == company_id).count() + 1
    return f"PR-{datetime.utcnow().strftime('%Y%m')}-{n:04d}"


@app.post("/api/payments/request")
def submit_payment_request(
    data: PaymentRequestIn,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    exp = db.query(ExpenseCode).filter(ExpenseCode.id == data.expense_code_id, ExpenseCode.company_id == current_user.company_id).first()
    if not exp:
        raise HTTPException(400, "Invalid expense code")
    bud = db.query(BudgetCode).filter(BudgetCode.id == data.budget_code_id, BudgetCode.company_id == current_user.company_id).first()
    if not bud:
        raise HTTPException(400, "Invalid budget code")
    approver = db.query(User).filter(
        User.id == data.designated_approver_id,
        User.company_id == current_user.company_id,
        User.can_approve_payment == True,
    ).first()
    # Project strongly recommended; allow submit without for backward compatibility
    if not approver:
        raise HTTPException(400, "Select a valid approver for this budget line")

    debit_id = data.debit_account_id or exp.default_debit_account_id
    credit_id = data.credit_account_id or exp.default_credit_account_id

    pr = PaymentRequest(
        company_id=current_user.company_id,
        request_no=next_request_no(db, current_user.company_id),
        requester_id=current_user.id,
        budget_code_id=data.budget_code_id,
        expense_code_id=data.expense_code_id,
        amount=data.amount,
        narration=data.narration,
        payee_name=data.payee_name,
        debit_account_id=debit_id,
        credit_account_id=credit_id,
        designated_approver_id=data.designated_approver_id,
        project_code_id=getattr(data, "project_code_id", None),
        amount_in_words=amount_to_words(getattr(data, "amount", 0)),
        line_items_json=__import__("json").dumps([li.dict() if hasattr(li, "dict") else (li.model_dump() if hasattr(li, "model_dump") else li) for li in (getattr(data, "line_items", None) or [])]),
        status="submitted",
    )
    db.add(pr)
    db.commit()
    db.refresh(pr)
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="submit", comment="Submitted"))
    db.commit()
    return pr


@app.get("/api/payments")
def list_payments(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    q = db.query(PaymentRequest).filter(PaymentRequest.company_id == current_user.company_id)
    # non-finance/program see own or designated
    if current_user.role not in ("finance", "program", "project_manager", "company_admin", "superadmin"):
        q = q.filter(
            (PaymentRequest.requester_id == current_user.id) |
            (PaymentRequest.designated_approver_id == current_user.id)
        )
    rows = q.order_by(PaymentRequest.created_at.desc()).all()
    out = []
    for p in rows:
        exp = db.query(ExpenseCode).filter(ExpenseCode.id == p.expense_code_id).first()
        bud = db.query(BudgetCode).filter(BudgetCode.id == p.budget_code_id).first()
        out.append({
            "id": p.id, "request_no": p.request_no, "amount": p.amount, "status": p.status,
            "payee_name": p.payee_name, "project_code_id": getattr(p, "project_code_id", None), "amount_in_words": getattr(p, "amount_in_words", "") or "", "line_items_json": getattr(p, "line_items_json", "[]") or "[]", "narration": p.narration,
            "expense_code": exp.code if exp else None,
            "expense_description": exp.description if exp else None,
            "budget_code": bud.code if bud else None,
            "debit_account_id": p.debit_account_id,
            "credit_account_id": p.credit_account_id,
            "designated_approver_id": p.designated_approver_id,
            "created_at": p.created_at.isoformat() if p.created_at else None,
        })
    return out


@app.post("/api/payments/{pid}/program-approve")
def program_approve(pid: int, data: PaymentAction, current_user: User = Depends(require_roles("program", "project_manager", "company_admin")), db: Session = Depends(get_db)):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr or pr.status != "submitted":
        raise HTTPException(400, "Request not awaiting program approval")
    if pr.designated_approver_id != current_user.id and current_user.role not in ("company_admin", "project_manager"):
        raise HTTPException(403, "You are not the designated approver for this budget line")
    pr.status = "program_approved"
    pr.program_approved_by = current_user.id
    pr.program_approved_at = datetime.utcnow()
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="program_approve", comment=data.comment))
    db.commit()
    return {"message": "Program approved", "status": pr.status}


@app.post("/api/payments/{pid}/finance-approve")
def finance_approve(pid: int, data: PaymentAction, current_user: User = Depends(require_roles("finance", "company_admin")), db: Session = Depends(get_db)):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr or pr.status != "program_approved":
        raise HTTPException(400, "Request not awaiting finance approval")
    # Finance must ensure accounts
    if data.debit_account_id:
        pr.debit_account_id = data.debit_account_id
    if data.credit_account_id:
        pr.credit_account_id = data.credit_account_id
    if not pr.debit_account_id or not pr.credit_account_id:
        raise HTTPException(400, "Finance must set debit and credit accounts before approval")
    pr.status = "finance_approved"
    pr.finance_approved_by = current_user.id
    pr.finance_approved_at = datetime.utcnow()
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="finance_approve", comment=data.comment))
    db.commit()
    return {"message": "Finance approved", "status": pr.status}


@app.post("/api/payments/{pid}/pay")
def mark_paid(pid: int, data: PaymentAction, current_user: User = Depends(require_roles("finance", "company_admin")), db: Session = Depends(get_db)):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr or pr.status != "finance_approved":
        raise HTTPException(400, "Request not ready for payment")
    if not pr.debit_account_id or not pr.credit_account_id:
        raise HTTPException(400, "Debit and credit accounts required before payment")
    pr.status = "paid"
    pr.paid_at = datetime.utcnow()
    bud = db.query(BudgetCode).filter(BudgetCode.id == pr.budget_code_id).first()
    if bud:
        bud.spent = (bud.spent or 0) + pr.amount
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="pay", comment=data.comment))
    post_double_entry(
        db, current_user.company_id, current_user.id,
        "payment", pr.id, f"Payment {pr.request_no}", pr.narration or pr.payee_name,
        pr.debit_account_id, pr.credit_account_id, pr.amount,
    )
    db.commit()
    return {"message": "Marked as paid and posted to ledger", "status": pr.status}


@app.post("/api/payments/{pid}/reject")
def reject_payment(pid: int, data: PaymentAction, current_user: User = Depends(require_roles("finance", "program", "project_manager", "company_admin")), db: Session = Depends(get_db)):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr:
        raise HTTPException(404, "Not found")
    pr.status = "rejected"
    pr.rejection_reason = data.comment
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="reject", comment=data.comment))
    db.commit()
    return {"message": "Rejected", "status": pr.status}


@app.get("/api/payments/export")
def export_payments_csv(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(PaymentRequest).filter(PaymentRequest.company_id == current_user.company_id).all()
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(["Request No", "Amount", "Status", "Payee", "Narration", "Created"])
    for p in rows:
        w.writerow([p.request_no, p.amount, p.status, p.payee_name, p.narration, p.created_at])
    si.seek(0)
    return StreamingResponse(iter([si.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=payments.csv"})


# ===================== ASSETS =====================
def can_edit_assets(user: User) -> bool:
    return user.can_edit_assets or user.role in ("finance", "project_manager", "company_admin", "asset_editor", "superadmin")


def can_view_assets(user: User) -> bool:
    return user.can_access_assets or can_edit_assets(user)


@app.get("/api/assets")
def list_assets(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_view_assets(current_user):
        raise HTTPException(403, "No access to assets")
    return db.query(Asset).filter(Asset.company_id == current_user.company_id).order_by(Asset.id.desc()).all()


@app.post("/api/assets")
def create_asset(data: AssetIn, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_edit_assets(current_user):
        raise HTTPException(403, "Only designated staff, finance, or project manager can edit the asset register")
    a = Asset(company_id=current_user.company_id, created_by=current_user.id, **data.dict())
    db.add(a)
    db.commit()
    db.refresh(a)
    return a


@app.put("/api/assets/{asset_id}")
def update_asset(asset_id: int, data: AssetIn, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_edit_assets(current_user):
        raise HTTPException(403, "Not allowed to edit assets")
    a = db.query(Asset).filter(Asset.id == asset_id, Asset.company_id == current_user.company_id).first()
    if not a:
        raise HTTPException(404, "Asset not found")
    for f, v in data.dict().items():
        setattr(a, f, v)
    db.commit()
    db.refresh(a)
    return a


@app.post("/api/assets/{asset_id}/photo")
async def upload_asset_photo(
    asset_id: int,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    if not can_edit_assets(current_user):
        raise HTTPException(403, "Not allowed")
    a = db.query(Asset).filter(Asset.id == asset_id, Asset.company_id == current_user.company_id).first()
    if not a:
        raise HTTPException(404, "Asset not found")
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_IMAGE:
        raise HTTPException(400, "Only image files allowed")
    # size limit ~5MB
    content = await file.read()
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(400, "Image too large (max 5MB)")
    fname = f"asset_{current_user.company_id}_{asset_id}{ext}"
    dest = UPLOADS_DIR / fname
    dest.write_bytes(content)
    a.image_path = f"/static/uploads/{fname}"
    db.commit()
    return {"image_path": a.image_path}


@app.get("/api/assets/export")
def export_assets_csv(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_view_assets(current_user):
        raise HTTPException(403, "No access")
    rows = db.query(Asset).filter(Asset.company_id == current_user.company_id).all()
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(["Asset Number", "Name", "Category", "Location", "Cost", "NBV", "Condition", "Insurance"])
    for a in rows:
        w.writerow([a.asset_number, a.asset_name, a.category, a.location, a.cost, a.nbv, a.condition, a.insurance])
    si.seek(0)
    return StreamingResponse(iter([si.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=assets.csv"})


@app.get("/api/dashboard/stats")
def dashboard_stats(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    cid = current_user.company_id
    if not cid:
        # superadmin overview
        return {
            "companies_pending": db.query(Company).filter(Company.status == "pending").count(),
            "companies_approved": db.query(Company).filter(Company.status == "approved").count(),
            "companies_total": db.query(Company).count(),
        }
    assets = db.query(Asset).filter(Asset.company_id == cid).all()
    payments = db.query(PaymentRequest).filter(PaymentRequest.company_id == cid).all()
    return {
        "assets_count": len(assets),
        "assets_value": sum(a.nbv or a.cost or 0 for a in assets),
        "payments_pending": sum(1 for p in payments if p.status in ("submitted", "program_approved")),
        "payments_paid": sum(1 for p in payments if p.status == "paid"),
        "payments_total_amount": sum(p.amount for p in payments if p.status == "paid"),
        "users_count": db.query(User).filter(User.company_id == cid).count(),
        "condition_breakdown": {
            "Good": sum(1 for a in assets if (a.condition or "").lower() == "good"),
            "Fair": sum(1 for a in assets if (a.condition or "").lower() == "fair"),
            "Bad": sum(1 for a in assets if (a.condition or "").lower() == "bad"),
            "Lost": sum(1 for a in assets if (a.condition or "").lower() == "lost"),
        },
        "payment_status_breakdown": {
            "submitted": sum(1 for p in payments if p.status == "submitted"),
            "program_approved": sum(1 for p in payments if p.status == "program_approved"),
            "finance_approved": sum(1 for p in payments if p.status == "finance_approved"),
            "paid": sum(1 for p in payments if p.status == "paid"),
            "rejected": sum(1 for p in payments if p.status == "rejected"),
        },
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "version": "2.2.0", "multi_tenant": True, "licensing": True}



# ===================== HELPERS: JOURNAL POSTING =====================
def next_entry_no(db, company_id, prefix="JE"):
    n = db.query(JournalEntry).filter(JournalEntry.company_id == company_id).count() + 1
    return f"{prefix}-{datetime.utcnow().strftime('%Y%m')}-{n:05d}"


def post_double_entry(db, company_id, user_id, source_type, source_id, description, narration,
                      debit_account_id, credit_account_id, amount, project_code_id=None, entry_date=None):
    """Post balanced debit/credit lines to the general ledger."""
    if not debit_account_id or not credit_account_id:
        raise HTTPException(400, "Debit and credit accounts are required")
    if amount is None or float(amount) == 0:
        raise HTTPException(400, "Amount must be non-zero")
    amt = abs(float(amount))
    entry_no = next_entry_no(db, company_id)
    ed = entry_date or date.today()
    db.add(JournalEntry(
        company_id=company_id, entry_no=entry_no, entry_date=ed,
        source_type=source_type, source_id=source_id,
        account_id=debit_account_id, project_code_id=project_code_id,
        description=description, narration=narration,
        debit=amt, credit=0.0, created_by=user_id,
    ))
    db.add(JournalEntry(
        company_id=company_id, entry_no=entry_no, entry_date=ed,
        source_type=source_type, source_id=source_id,
        account_id=credit_account_id, project_code_id=project_code_id,
        description=description, narration=narration,
        debit=0.0, credit=amt, created_by=user_id,
    ))
    return entry_no


def cleanup_disposed_assets(db: Session):
    """Delete assets disposed more than 14 days ago."""
    cutoff = datetime.utcnow() - timedelta(days=14)
    old = db.query(Asset).filter(
        Asset.status == "disposed",
        Asset.disposed_at != None,
        Asset.disposed_at < cutoff,
    ).all()
    for a in old:
        db.delete(a)
    if old:
        db.commit()
        print(f"🧹 Removed {len(old)} disposed assets older than 14 days")


# ===================== PAYMENT DETAIL + ATTACHMENTS (<=100KB) =====================
MAX_ATTACH = 100 * 1024  # 100 KB


@app.get("/api/payments/{pid}")
def get_payment_detail(pid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr:
        raise HTTPException(404, "Payment request not found")
    exp = db.query(ExpenseCode).filter(ExpenseCode.id == pr.expense_code_id).first()
    bud = db.query(BudgetCode).filter(BudgetCode.id == pr.budget_code_id).first()
    debit = db.query(ChartOfAccount).filter(ChartOfAccount.id == pr.debit_account_id).first() if pr.debit_account_id else None
    credit = db.query(ChartOfAccount).filter(ChartOfAccount.id == pr.credit_account_id).first() if pr.credit_account_id else None
    requester = db.query(User).filter(User.id == pr.requester_id).first()
    approver = db.query(User).filter(User.id == pr.designated_approver_id).first()
    atts = db.query(PaymentAttachment).filter(PaymentAttachment.payment_request_id == pr.id).all()
    logs = db.query(PaymentApprovalLog).filter(PaymentApprovalLog.payment_request_id == pr.id).order_by(PaymentApprovalLog.created_at).all()
    return {
        "id": pr.id, "request_no": pr.request_no, "amount": pr.amount, "status": pr.status,
        "payee_name": pr.payee_name, "narration": pr.narration, "currency": pr.currency,
        "budget_code": bud.code if bud else None, "budget_description": bud.description if bud else None,
        "expense_code": exp.code if exp else None, "expense_description": exp.description if exp else None,
        "debit_account": f"{debit.code} - {debit.name}" if debit else None,
        "credit_account": f"{credit.code} - {credit.name}" if credit else None,
        "debit_account_id": pr.debit_account_id, "credit_account_id": pr.credit_account_id,
        "requester": requester.full_name or requester.username if requester else None,
        "designated_approver": approver.full_name or approver.username if approver else None,
        "rejection_reason": pr.rejection_reason,
        "created_at": pr.created_at.isoformat() if pr.created_at else None,
        "program_approved_at": pr.program_approved_at.isoformat() if pr.program_approved_at else None,
        "finance_approved_at": pr.finance_approved_at.isoformat() if pr.finance_approved_at else None,
        "paid_at": pr.paid_at.isoformat() if pr.paid_at else None,
        "attachments": [{"id": a.id, "filename": a.filename, "size_bytes": a.size_bytes, "url": a.stored_path} for a in atts],
        "history": [{"action": l.action, "comment": l.comment, "at": l.created_at.isoformat() if l.created_at else None} for l in logs],
    }


@app.post("/api/payments/{pid}/attachments")
async def upload_payment_attachment(
    pid: int,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr:
        raise HTTPException(404, "Not found")
    content = await file.read()
    if len(content) > MAX_ATTACH:
        raise HTTPException(400, f"Attachment must be ≤ 100KB (got {len(content)} bytes)")
    ext = Path(file.filename or "file").suffix.lower()
    if ext not in {".pdf", ".png", ".jpg", ".jpeg", ".csv", ".xlsx", ".doc", ".docx", ".txt"}:
        raise HTTPException(400, "File type not allowed")
    safe = f"pay_{current_user.company_id}_{pid}_{secrets.token_hex(4)}{ext}"
    dest = UPLOADS_DIR / safe
    dest.write_bytes(content)
    att = PaymentAttachment(
        payment_request_id=pr.id,
        filename=file.filename or safe,
        stored_path=f"/static/uploads/{safe}",
        content_type=file.content_type or "application/octet-stream",
        size_bytes=len(content),
        uploaded_by=current_user.id,
    )
    db.add(att)
    db.commit()
    db.refresh(att)
    return {"id": att.id, "filename": att.filename, "url": att.stored_path, "size_bytes": att.size_bytes}


# When marking paid, post to ledger
_orig_mark = None  # we patch mark_paid below by replacing function body via string if needed

# ===================== PROJECT CODES =====================
@app.get("/api/finance/projects")
def list_projects(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    return db.query(ProjectCode).filter(ProjectCode.company_id == current_user.company_id, ProjectCode.is_active == True).all()


@app.post("/api/finance/projects")
def create_project(
    code: str = Form(...), name: str = Form(...), description: str = Form(""),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    row = ProjectCode(company_id=current_user.company_id, code=code, name=name, description=description)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


# ===================== LEDGER / TRIAL BALANCE / REPORTS =====================
@app.get("/api/reports/ledger")
def general_ledger(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not (current_user.can_access_reports or current_user.role in ("finance", "company_admin", "superadmin")):
        raise HTTPException(403, "No report access")
    rows = db.query(JournalEntry).filter(JournalEntry.company_id == current_user.company_id).order_by(JournalEntry.entry_date, JournalEntry.id).all()
    out = []
    for j in rows:
        acc = db.query(ChartOfAccount).filter(ChartOfAccount.id == j.account_id).first()
        out.append({
            "entry_no": j.entry_no, "date": str(j.entry_date), "source_type": j.source_type,
            "account": f"{acc.code} - {acc.name}" if acc else str(j.account_id),
            "description": j.description, "narration": j.narration,
            "debit": j.debit, "credit": j.credit,
        })
    return out


@app.get("/api/reports/trial-balance")
def trial_balance(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not (current_user.can_access_reports or current_user.role in ("finance", "company_admin", "superadmin")):
        raise HTTPException(403, "No report access")
    accounts = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == current_user.company_id).all()
    result = []
    total_d = total_c = 0.0
    for acc in accounts:
        lines = db.query(JournalEntry).filter(JournalEntry.company_id == current_user.company_id, JournalEntry.account_id == acc.id).all()
        d = sum(l.debit or 0 for l in lines)
        c = sum(l.credit or 0 for l in lines)
        if d == 0 and c == 0:
            continue
        total_d += d
        total_c += c
        result.append({
            "code": acc.code, "name": acc.name, "type": acc.account_type,
            "project_code": acc.project_code or "",
            "debit": d, "credit": c, "balance": d - c,
        })
    return {"rows": result, "total_debit": total_d, "total_credit": total_c, "balanced": abs(total_d - total_c) < 0.01}


@app.get("/api/reports/ledger/export")
def export_ledger_csv(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = general_ledger(current_user, db)
    si = io.StringIO()
    w = csv.DictWriter(si, fieldnames=["entry_no", "date", "source_type", "account", "description", "narration", "debit", "credit"])
    w.writeheader()
    for r in data:
        w.writerow(r)
    si.seek(0)
    return StreamingResponse(iter([si.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=general_ledger.csv"})


@app.get("/api/reports/trial-balance/export")
def export_tb_csv(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = trial_balance(current_user, db)
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(["Code", "Name", "Type", "Project", "Debit", "Credit", "Balance"])
    for r in data["rows"]:
        w.writerow([r["code"], r["name"], r["type"], r["project_code"], r["debit"], r["credit"], r["balance"]])
    w.writerow([])
    w.writerow(["TOTAL", "", "", "", data["total_debit"], data["total_credit"], ""])
    si.seek(0)
    return StreamingResponse(iter([si.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=trial_balance.csv"})


# ===================== ASSET DETAIL + ACCOUNTING + DISPOSE =====================
@app.get("/api/assets/dashboard")
def assets_dashboard(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_view_assets(current_user):
        raise HTTPException(403, "No access")
    assets = db.query(Asset).filter(Asset.company_id == current_user.company_id, Asset.status != "disposed").all()
    # also include disposed for stats? exclude from main lists
    all_a = db.query(Asset).filter(Asset.company_id == current_user.company_id).all()
    insured = sum(1 for a in assets if (a.insurance or "").lower() in ("yes", "y", "true", "insured"))
    return {
        "total": len(assets),
        "insured": insured,
        "uninsured": len(assets) - insured,
        "damaged": sum(1 for a in assets if (a.condition or "").lower() in ("bad", "damaged")),
        "under_repair": sum(1 for a in assets if (a.status or "").lower() == "under_repair"),
        "disposed": sum(1 for a in all_a if (a.status or "").lower() == "disposed"),
        "total_cost": sum(a.cost or 0 for a in assets),
        "total_nbv": sum(a.nbv or 0 for a in assets),
        "by_condition": {
            "Good": sum(1 for a in assets if (a.condition or "").lower() == "good"),
            "Fair": sum(1 for a in assets if (a.condition or "").lower() == "fair"),
            "Bad": sum(1 for a in assets if (a.condition or "").lower() in ("bad", "damaged")),
            "Lost": sum(1 for a in assets if (a.condition or "").lower() == "lost"),
        },
        "useful_life_buckets": {
            "0-2 yrs": sum(1 for a in assets if (a.useful_life or 0) <= 2),
            "3-5 yrs": sum(1 for a in assets if 2 < (a.useful_life or 0) <= 5),
            "6-10 yrs": sum(1 for a in assets if 5 < (a.useful_life or 0) <= 10),
            "10+ yrs": sum(1 for a in assets if (a.useful_life or 0) > 10),
        },
    }


@app.get("/api/assets/{asset_id}")
def get_asset(asset_id: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_view_assets(current_user):
        raise HTTPException(403, "No access")
    a = db.query(Asset).filter(Asset.id == asset_id, Asset.company_id == current_user.company_id).first()
    if not a:
        raise HTTPException(404, "Asset not found")
    entries = db.query(AssetAccountingEntry).filter(AssetAccountingEntry.asset_id == a.id).order_by(AssetAccountingEntry.created_at.desc()).all()
    debit = db.query(ChartOfAccount).filter(ChartOfAccount.id == a.debit_account_id).first() if a.debit_account_id else None
    credit = db.query(ChartOfAccount).filter(ChartOfAccount.id == a.credit_account_id).first() if a.credit_account_id else None
    return {
        **{c.name: getattr(a, c.name) for c in a.__table__.columns},
        "debit_account_label": f"{debit.code} - {debit.name}" if debit else None,
        "credit_account_label": f"{credit.code} - {credit.name}" if credit else None,
        "accounting_entries": [{
            "id": e.id, "date": str(e.entry_date), "description": e.description,
            "narration": e.narration, "amount": e.amount, "journal_entry_no": e.journal_entry_no,
        } for e in entries],
    }


@app.post("/api/assets/{asset_id}/accounting")
def post_asset_accounting(
    asset_id: int,
    amount: float = Form(...),
    description: str = Form(...),
    narration: str = Form(""),
    debit_account_id: int = Form(...),
    credit_account_id: int = Form(...),
    project_code_id: Optional[int] = Form(None),
    current_user: User = Depends(require_roles("finance", "company_admin", "project_manager")),
    db: Session = Depends(get_db),
):
    a = db.query(Asset).filter(Asset.id == asset_id, Asset.company_id == current_user.company_id).first()
    if not a:
        raise HTTPException(404, "Asset not found")
    entry_no = post_double_entry(
        db, current_user.company_id, current_user.id,
        "asset_adjustment", a.id, description, narration,
        debit_account_id, credit_account_id, amount, project_code_id,
    )
    a.nbv = (a.nbv or 0) + float(amount)
    db.add(AssetAccountingEntry(
        company_id=current_user.company_id, asset_id=a.id,
        description=description, narration=narration, amount=float(amount),
        debit_account_id=debit_account_id, credit_account_id=credit_account_id,
        project_code_id=project_code_id, journal_entry_no=entry_no, created_by=current_user.id,
    ))
    db.commit()
    return {"message": "Accounting entry posted", "journal_entry_no": entry_no, "new_nbv": a.nbv}


@app.post("/api/assets/{asset_id}/dispose")
def dispose_asset(asset_id: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not can_edit_assets(current_user):
        raise HTTPException(403, "Not allowed")
    a = db.query(Asset).filter(Asset.id == asset_id, Asset.company_id == current_user.company_id).first()
    if not a:
        raise HTTPException(404, "Not found")
    a.status = "disposed"
    a.disposed_at = datetime.utcnow()
    a.condition = "Disposed"
    db.commit()
    return {"message": "Asset marked disposed. It will be auto-deleted after 14 days."}


# On asset create, optional initial capitalization journal if accounts provided
# (handled in frontend + optional extend create_asset)

# ===================== INVENTORY =====================
@app.get("/api/inventory")
def list_inventory(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not (current_user.can_access_inventory or current_user.role in ("finance", "company_admin", "superadmin")):
        raise HTTPException(403, "No inventory access")
    return db.query(InventoryItem).filter(InventoryItem.company_id == current_user.company_id).order_by(InventoryItem.id.desc()).all()


@app.post("/api/inventory")
def create_inventory(
    item_code: str = Form(...), item_name: str = Form(...), category: str = Form(""),
    department: str = Form(""), cost_price: float = Form(0), qty_received: float = Form(0),
    note: str = Form(""), receive_method: str = Form(""), funding_source: str = Form(""),
    debit_account_id: Optional[int] = Form(None), credit_account_id: Optional[int] = Form(None),
    project_code_id: Optional[int] = Form(None),
    current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db),
):
    if not (current_user.can_access_inventory or current_user.role in ("finance", "company_admin")):
        raise HTTPException(403, "No access")
    bal = float(qty_received)
    total = bal * float(cost_price)
    item = InventoryItem(
        company_id=current_user.company_id, item_code=item_code, item_name=item_name,
        category=category, department=department, cost_price=cost_price,
        qty_received=bal, qty_issued=0, balance_qty=bal, total_value=total,
        note=note, receive_method=receive_method, funding_source=funding_source,
        debit_account_id=debit_account_id, credit_account_id=credit_account_id,
        project_code_id=project_code_id,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    if debit_account_id and credit_account_id and total > 0:
        post_double_entry(
            db, current_user.company_id, current_user.id,
            "inventory", item.id, f"Stock receive {item_code}", note or item_name,
            debit_account_id, credit_account_id, total, project_code_id,
        )
        db.commit()
    return item


@app.post("/api/inventory/{item_id}/move")
def inventory_move(
    item_id: int,
    movement_type: str = Form(...),  # receive | issue
    quantity: float = Form(...),
    unit_cost: float = Form(0),
    narration: str = Form(""),
    debit_account_id: Optional[int] = Form(None),
    credit_account_id: Optional[int] = Form(None),
    current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db),
):
    item = db.query(InventoryItem).filter(InventoryItem.id == item_id, InventoryItem.company_id == current_user.company_id).first()
    if not item:
        raise HTTPException(404, "Item not found")
    qty = float(quantity)
    cost = float(unit_cost) or (item.cost_price or 0)
    total = qty * cost
    if movement_type == "receive":
        item.qty_received = (item.qty_received or 0) + qty
        item.balance_qty = (item.balance_qty or 0) + qty
    elif movement_type == "issue":
        if qty > (item.balance_qty or 0):
            raise HTTPException(400, "Insufficient stock")
        item.qty_issued = (item.qty_issued or 0) + qty
        item.balance_qty = (item.balance_qty or 0) - qty
    else:
        raise HTTPException(400, "movement_type must be receive or issue")
    item.total_value = (item.balance_qty or 0) * (item.cost_price or cost)
    item.last_updated = datetime.utcnow()
    debit = debit_account_id or item.debit_account_id
    credit = credit_account_id or item.credit_account_id
    db.add(InventoryMovement(
        company_id=current_user.company_id, item_id=item.id, movement_type=movement_type,
        quantity=qty, unit_cost=cost, total=total, narration=narration,
        debit_account_id=debit, credit_account_id=credit, created_by=current_user.id,
    ))
    if debit and credit and total > 0:
        # issue: expense/COGS debit, inventory credit; receive: inventory debit, cash/AP credit
        if movement_type == "issue":
            post_double_entry(db, current_user.company_id, current_user.id, "inventory", item.id,
                              f"Issue {item.item_code}", narration, debit, credit, total)
        else:
            post_double_entry(db, current_user.company_id, current_user.id, "inventory", item.id,
                              f"Receive {item.item_code}", narration, debit, credit, total)
    db.commit()
    db.refresh(item)
    return item


@app.get("/api/inventory/export")
def export_inventory(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(InventoryItem).filter(InventoryItem.company_id == current_user.company_id).all()
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(["Item Code", "Name", "Category", "Department", "Cost", "Received", "Issued", "Balance", "Total Value"])
    for i in rows:
        w.writerow([i.item_code, i.item_name, i.category, i.department, i.cost_price, i.qty_received, i.qty_issued, i.balance_qty, i.total_value])
    si.seek(0)
    return StreamingResponse(iter([si.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=inventory.csv"})


# ===================== VENDORS =====================
@app.get("/api/vendors")
def list_vendors(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    if not (current_user.can_access_vendors or current_user.role in ("finance", "company_admin", "superadmin")):
        raise HTTPException(403, "No vendor access")
    return db.query(Vendor).filter(Vendor.company_id == current_user.company_id).order_by(Vendor.id.desc()).all()


@app.post("/api/vendors")
def create_vendor(
    vendor_number: str = Form(...), name: str = Form(...), address: str = Form(""),
    cac_number: str = Form(""), experience: str = Form(""), tax_clearance: str = Form(""),
    bank: str = Form(""), reg_with_govt: str = Form(""), audit_3yrs: str = Form(""),
    description: str = Form(""), amount: float = Form(0),
    debit_account_id: Optional[int] = Form(None), credit_account_id: Optional[int] = Form(None),
    current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db),
):
    if not (current_user.can_access_vendors or current_user.role in ("finance", "company_admin")):
        raise HTTPException(403, "No access")
    # simple score like original analyze
    score = 0
    if tax_clearance.lower() in ("yes", "y"): score += 25
    if reg_with_govt.lower() in ("yes", "y"): score += 25
    if audit_3yrs.lower() in ("yes", "y"): score += 25
    if experience: score += min(25, len(experience))
    v = Vendor(
        company_id=current_user.company_id, vendor_number=vendor_number, name=name,
        address=address, cac_number=cac_number, experience=experience, tax_clearance=tax_clearance,
        bank=bank, reg_with_govt=reg_with_govt, audit_3yrs=audit_3yrs, description=description,
        amount=amount, score=score, debit_account_id=debit_account_id, credit_account_id=credit_account_id,
    )
    db.add(v)
    db.commit()
    db.refresh(v)
    if debit_account_id and credit_account_id and amount > 0:
        post_double_entry(
            db, current_user.company_id, current_user.id, "vendor", v.id,
            f"Vendor commitment {name}", description or name,
            debit_account_id, credit_account_id, amount,
        )
        db.commit()
    return v


@app.get("/api/vendors/export")
def export_vendors(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(Vendor).filter(Vendor.company_id == current_user.company_id).all()
    si = io.StringIO()
    w = csv.writer(si)
    w.writerow(["Vendor No", "Name", "CAC", "Tax Clearance", "Bank", "Amount", "Score", "Description"])
    for v in rows:
        w.writerow([v.vendor_number, v.name, v.cac_number, v.tax_clearance, v.bank, v.amount, v.score, v.description])
    si.seek(0)
    return StreamingResponse(iter([si.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=vendors.csv"})


# Patch mark_paid to post journal



@app.post("/api/finance/journal")
def post_manual_journal(
    description: str = Form(...),
    narration: str = Form(""),
    debit_account_id: int = Form(...),
    credit_account_id: int = Form(...),
    amount: float = Form(...),
    project_code_id: Optional[int] = Form(None),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    entry_no = post_double_entry(
        db, current_user.company_id, current_user.id,
        "manual", None, description, narration,
        debit_account_id, credit_account_id, amount, project_code_id,
    )
    db.commit()
    return {"message": "Journal posted", "entry_no": entry_no}


@app.get("/api/finance/bank-lines")
def bank_cash_lines(current_user: User = Depends(require_roles("finance", "company_admin")), db: Session = Depends(get_db)):
    """Ledger lines for Cash-type accounts for reconciliation."""
    cash_ids = [a.id for a in db.query(ChartOfAccount).filter(
        ChartOfAccount.company_id == current_user.company_id,
        ChartOfAccount.account_type == "Cash",
    ).all()]
    if not cash_ids:
        return []
    rows = db.query(JournalEntry).filter(
        JournalEntry.company_id == current_user.company_id,
        JournalEntry.account_id.in_(cash_ids),
    ).order_by(JournalEntry.entry_date.desc()).limit(200).all()
    out = []
    for j in rows:
        acc = db.query(ChartOfAccount).filter(ChartOfAccount.id == j.account_id).first()
        out.append({
            "id": j.id, "entry_no": j.entry_no, "date": str(j.entry_date),
            "account": f"{acc.code} - {acc.name}" if acc else "",
            "description": j.description, "debit": j.debit, "credit": j.credit,
            "narration": j.narration,
        })
    return out




# ===================== BANK RECONCILIATION (full) =====================
@app.get("/api/finance/bank-recon")
def bank_recon_lines(
    account_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    cid = current_user.company_id
    q_acc = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == cid, ChartOfAccount.account_type == "Cash")
    cash_accounts = q_acc.all()
    cash_ids = [a.id for a in cash_accounts]
    if account_id:
        cash_ids = [account_id] if account_id in cash_ids or True else cash_ids

    q = db.query(JournalEntry).filter(JournalEntry.company_id == cid, JournalEntry.account_id.in_(cash_ids) if cash_ids else False)
    if start_date:
        try:
            q = q.filter(JournalEntry.entry_date >= date.fromisoformat(start_date))
        except Exception:
            pass
    if end_date:
        try:
            q = q.filter(JournalEntry.entry_date <= date.fromisoformat(end_date))
        except Exception:
            pass
    rows = q.order_by(JournalEntry.entry_date, JournalEntry.id).all()

    running = 0.0
    out = []
    reconciled_total = 0.0
    outstanding_total = 0.0
    for j in rows:
        running += (j.debit or 0) - (j.credit or 0)
        st = db.query(BankReconState).filter(
            BankReconState.company_id == cid, BankReconState.journal_entry_id == j.id
        ).first()
        ticked = bool(st and st.ticked)
        net = (j.debit or 0) - (j.credit or 0)
        if ticked:
            reconciled_total += abs(net)
        else:
            outstanding_total += abs(net)
        acc = db.query(ChartOfAccount).filter(ChartOfAccount.id == j.account_id).first()
        out.append({
            "journal_entry_id": j.id,
            "entry_no": j.entry_no,
            "date": str(j.entry_date),
            "account_id": j.account_id,
            "account": f"{acc.code} - {acc.name}" if acc else "",
            "description": j.description,
            "narration": j.narration,
            "debit": j.debit,
            "credit": j.credit,
            "balance": running,
            "ticked": ticked,
            "source_type": j.source_type,
            "source_id": j.source_id,
        })
    return {
        "lines": out,
        "cash_accounts": [{"id": a.id, "code": a.code, "name": a.name} for a in cash_accounts],
        "totals": {
            "reconciled": reconciled_total,
            "outstanding": outstanding_total,
            "book_balance": running,
        },
    }


@app.post("/api/finance/bank-recon/tick")
def bank_recon_tick(
    journal_entry_id: int = Form(...),
    ticked: bool = Form(True),
    note: str = Form(""),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    cid = current_user.company_id
    je = db.query(JournalEntry).filter(JournalEntry.id == journal_entry_id, JournalEntry.company_id == cid).first()
    if not je:
        raise HTTPException(404, "Journal line not found")
    st = db.query(BankReconState).filter(
        BankReconState.company_id == cid, BankReconState.journal_entry_id == journal_entry_id
    ).first()
    if not st:
        st = BankReconState(company_id=cid, journal_entry_id=journal_entry_id)
        db.add(st)
    st.ticked = ticked
    st.ticked_by = current_user.id
    st.ticked_at = datetime.utcnow() if ticked else None
    st.note = note
    db.commit()
    return {"ok": True, "ticked": st.ticked}


@app.post("/api/finance/bank-recon/session")
def save_bank_session(
    account_id: int = Form(...),
    statement_balance: float = Form(0),
    book_balance: float = Form(0),
    bank_charges: float = Form(0),
    bank_charges_note: str = Form(""),
    unpresented_cheques: float = Form(0),
    deposits_in_transit: float = Form(0),
    start_date: Optional[str] = Form(None),
    end_date: Optional[str] = Form(None),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    """Save recon inputs. Statement balance = closing bank statement; book balance = cashbook after ticks."""
    sd = date.fromisoformat(start_date) if start_date else None
    ed = date.fromisoformat(end_date) if end_date else None
    sess = BankStatementSession(
        company_id=current_user.company_id, account_id=account_id,
        start_date=sd, end_date=ed,
        statement_balance=statement_balance,
        book_balance=book_balance,
        bank_charges=bank_charges,
        bank_charges_note=bank_charges_note or "",
        unpresented_cheques=unpresented_cheques,
        deposits_in_transit=deposits_in_transit,
        status="draft",
        created_by=current_user.id,
    )
    db.add(sess)
    db.commit()
    db.refresh(sess)
    return {
        "id": sess.id,
        "statement_balance": sess.statement_balance,
        "book_balance": sess.book_balance,
        "bank_charges": sess.bank_charges,
        "status": sess.status,
    }


@app.post("/api/finance/bank-recon/session/{session_id}/approve")
def approve_bank_session(
    session_id: int,
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    """Approve bank recon and apply reviewer stamp (initials + date)."""
    sess = db.query(BankStatementSession).filter(
        BankStatementSession.id == session_id,
        BankStatementSession.company_id == current_user.company_id,
    ).first()
    if not sess:
        raise HTTPException(404, "Session not found")
    # Initials from full name or username
    name = (current_user.full_name or current_user.username or "RV").strip()
    parts = name.replace(".", " ").split()
    initials = "".join(p[0].upper() for p in parts if p)[:4] or "RV"
    stamp = f"{initials} · {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"
    sess.status = "approved"
    sess.approved_by = current_user.id
    sess.approved_at = datetime.utcnow()
    sess.approver_stamp = stamp
    db.commit()
    return {"ok": True, "stamp": stamp, "status": "approved", "session_id": sess.id}


@app.get("/api/finance/bank-recon/sessions")
def list_bank_sessions(
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    rows = db.query(BankStatementSession).filter(
        BankStatementSession.company_id == current_user.company_id
    ).order_by(BankStatementSession.id.desc()).limit(30).all()
    return [{
        "id": s.id, "account_id": s.account_id,
        "statement_balance": s.statement_balance, "book_balance": s.book_balance,
        "bank_charges": getattr(s, "bank_charges", 0) or 0,
        "status": getattr(s, "status", "draft"),
        "approver_stamp": getattr(s, "approver_stamp", None),
        "approved_at": str(s.approved_at) if s.approved_at else None,
        "created_at": str(s.created_at) if s.created_at else None,
    } for s in rows]


@app.get("/api/finance/transaction-trail/{journal_entry_id}")
def transaction_trail(
    journal_entry_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Follow a ledger line back to its source document."""
    j = db.query(JournalEntry).filter(
        JournalEntry.id == journal_entry_id, JournalEntry.company_id == current_user.company_id
    ).first()
    if not j:
        raise HTTPException(404, "Not found")
    # paired lines same entry_no
    pair = db.query(JournalEntry).filter(
        JournalEntry.company_id == current_user.company_id, JournalEntry.entry_no == j.entry_no
    ).all()
    source = None
    if j.source_type == "payment" and j.source_id:
        pr = db.query(PaymentRequest).filter(PaymentRequest.id == j.source_id).first()
        if pr:
            source = {"type": "payment", "id": pr.id, "ref": pr.request_no, "payee": pr.payee_name, "amount": pr.amount, "status": pr.status}
    elif j.source_type == "inventory" and j.source_id:
        inv = db.query(InventoryItem).filter(InventoryItem.id == j.source_id).first()
        if inv:
            source = {"type": "inventory", "id": inv.id, "ref": inv.item_code, "name": inv.item_name}
    elif j.source_type == "asset_adjustment" and j.source_id:
        a = db.query(Asset).filter(Asset.id == j.source_id).first()
        if a:
            source = {"type": "asset", "id": a.id, "ref": a.asset_number, "name": a.asset_name}
    elif j.source_type == "vendor" and j.source_id:
        v = db.query(Vendor).filter(Vendor.id == j.source_id).first()
        if v:
            source = {"type": "vendor", "id": v.id, "ref": v.vendor_number, "name": v.name}
    creator = db.query(User).filter(User.id == j.created_by).first() if j.created_by else None
    return {
        "line": {
            "id": j.id, "entry_no": j.entry_no, "date": str(j.entry_date),
            "description": j.description, "narration": j.narration,
            "debit": j.debit, "credit": j.credit, "source_type": j.source_type, "source_id": j.source_id,
        },
        "paired_entries": [{
            "id": p.id, "account_id": p.account_id, "debit": p.debit, "credit": p.credit, "description": p.description
        } for p in pair],
        "source": source,
        "created_by": (creator.full_name or creator.username) if creator else None,
        "can_correct": current_user.role in ("finance", "company_admin", "superadmin"),
    }


@app.post("/api/finance/correction-request")
def create_correction_request(
    to_user_id: int = Form(...),
    message: str = Form(...),
    journal_entry_id: Optional[int] = Form(None),
    source_type: str = Form(""),
    source_id: Optional[int] = Form(None),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    row = CorrectionRequest(
        company_id=current_user.company_id,
        journal_entry_id=journal_entry_id,
        source_type=source_type,
        source_id=source_id,
        from_user_id=current_user.id,
        to_user_id=to_user_id,
        message=message,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"message": "Correction request sent", "id": row.id}


@app.get("/api/finance/correction-requests")
def list_corrections(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(CorrectionRequest).filter(
        CorrectionRequest.company_id == current_user.company_id,
        (CorrectionRequest.to_user_id == current_user.id) | (CorrectionRequest.from_user_id == current_user.id),
    ).order_by(CorrectionRequest.created_at.desc()).limit(100).all()
    out = []
    for c in rows:
        fu = db.query(User).filter(User.id == c.from_user_id).first()
        tu = db.query(User).filter(User.id == c.to_user_id).first()
        out.append({
            "id": c.id,
            "journal_entry_id": c.journal_entry_id,
            "message": c.message,
            "status": c.status,
            "from_user_id": c.from_user_id,
            "to_user_id": c.to_user_id,
            "from_user": (fu.full_name or fu.username) if fu else "",
            "to_user": (tu.full_name or tu.username) if tu else "",
            "created_at": str(c.created_at) if c.created_at else None,
        })
    return out


# ===================== BUDGET VARIANCE (per project) =====================
@app.get("/api/reports/budget-variance")
def budget_variance(
    project_code: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    cid = current_user.company_id
    budgets = db.query(BudgetCode).filter(BudgetCode.company_id == cid, BudgetCode.is_active == True).all()
    # actuals from payment requests paid + journal on expense accounts linked via expense codes
    rows = []
    total_b = total_a = 0.0
    for b in budgets:
        # filter by project if budget description/code contains project or via expense link
        if project_code and project_code.lower() not in (b.code or "").lower() and project_code.lower() not in (b.description or "").lower():
            # also check project codes table match
            pass  # still include if no strict link — filter loosely
            if project_code and project_code not in (b.code or "") and project_code not in (b.description or ""):
                continue
        actual = float(b.spent or 0)
        # also sum paid payments on this budget
        pays = db.query(PaymentRequest).filter(
            PaymentRequest.company_id == cid,
            PaymentRequest.budget_code_id == b.id,
            PaymentRequest.status == "paid",
        ).all()
        actual = max(actual, sum(p.amount for p in pays))
        budgeted = float(b.amount or 0)
        var = budgeted - actual
        rows.append({
            "budget_code": b.code,
            "description": b.description,
            "budgeted": budgeted,
            "actual": actual,
            "variance": var,
            "remark": "Favourable" if var >= 0 else "Adverse",
        })
        total_b += budgeted
        total_a += actual
    return {
        "project_code": project_code or "ALL",
        "rows": rows,
        "total_budget": total_b,
        "total_actual": total_a,
        "total_variance": total_b - total_a,
    }


# ===================== PDF / EXCEL REPORTS =====================
from reports import build_pdf, build_csv, build_bank_recon_pdf, build_payment_voucher_pdf, amount_to_words

def _dashboard_kpis(db, company_id):
    """Lightweight dashboard metrics for PDF page 1."""
    from sqlalchemy import func
    try:
        pay_pending = db.query(PaymentRequest).filter(
            PaymentRequest.company_id == company_id,
            PaymentRequest.status.in_(["submitted", "program_approved"]),
        ).count()
        pay_approved = db.query(PaymentRequest).filter(
            PaymentRequest.company_id == company_id,
            PaymentRequest.status.in_(["finance_approved", "paid", "approved"]),
        ).count()
        je_count = db.query(JournalEntry).filter(JournalEntry.company_id == company_id).count()
        return {
            "Payment requests pending": pay_pending,
            "Payments approved / paid": pay_approved,
            "Journal entries posted": je_count,
            "Report generated": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        }
    except Exception:
        return {"Report generated": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")}


STORED_DIR = Path("stored_reports")
STORED_DIR.mkdir(parents=True, exist_ok=True)


def _save_pdf_bytes(company_id, user_id, report_type, title, filename, buf):
    """Write PDF to internal folder for later sync/view."""
    safe = filename.replace("/", "_")
    dest = STORED_DIR / f"c{company_id}_{safe}"
    data = buf.getvalue() if hasattr(buf, "getvalue") else buf.read()
    if hasattr(buf, "seek"):
        buf.seek(0)
    dest.write_bytes(data if isinstance(data, (bytes, bytearray)) else bytes(data))
    return str(dest), safe




def _company_and_currency(db, user):
    co = db.query(Company).filter(Company.id == user.company_id).first() if user.company_id else None
    code = co.reporting_currency_code if co else "NGN"
    sym = co.reporting_currency_symbol if co else "₦"
    return co, code, sym




@app.post("/api/finance/correction-request/{cid}/resubmit")
def resubmit_correction(
    cid: int,
    debit: float = Form(...),
    credit: float = Form(...),
    description: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Staff assigned a correction opens the JE, corrects amounts, and resubmits."""
    cr = db.query(CorrectionRequest).filter(
        CorrectionRequest.id == cid, CorrectionRequest.company_id == current_user.company_id
    ).first()
    if not cr:
        raise HTTPException(404, "Correction request not found")
    if cr.to_user_id != current_user.id and current_user.role not in ("company_admin", "finance"):
        raise HTTPException(403, "Only the assigned staff can resubmit this correction")
    j = None
    if cr.journal_entry_id:
        j = db.query(JournalEntry).filter(JournalEntry.id == cr.journal_entry_id).first()
    if j:
        cr.original_debit = j.debit
        cr.original_credit = j.credit
        j.debit = debit
        j.credit = credit
        if description:
            j.description = description
        db.add(j)
    cr.corrected_debit = debit
    cr.corrected_credit = credit
    cr.corrected_description = description
    cr.status = "resubmitted"
    cr.resolved_at = datetime.utcnow()
    db.commit()
    return {"ok": True, "message": "Correction resubmitted for review", "status": cr.status}


@app.post("/api/finance/correction-request/{cid}/resolve")
def resolve_correction(
    cid: int,
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    cr = db.query(CorrectionRequest).filter(
        CorrectionRequest.id == cid, CorrectionRequest.company_id == current_user.company_id
    ).first()
    if not cr:
        raise HTTPException(404)
    cr.status = "resolved"
    cr.resolved_at = datetime.utcnow()
    db.commit()
    return {"ok": True}


@app.get("/api/reports/stored")
def list_stored_reports(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    rows = db.query(StoredReport).filter(
        StoredReport.company_id == current_user.company_id
    ).order_by(StoredReport.id.desc()).limit(50).all()
    return [{
        "id": r.id, "report_type": r.report_type, "title": r.title,
        "filename": r.filename, "synced": r.synced,
        "created_at": str(r.created_at) if r.created_at else None,
    } for r in rows]


@app.post("/api/reports/stored/sync")
def sync_stored_report(
    report_type: str = Form(...),
    title: str = Form(""),
    filename: str = Form(...),
    file_path: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Mark a downloaded PDF as synchronised into internal memory."""
    # Prefer path under STORED_DIR
    path = file_path or str(STORED_DIR / filename)
    rec = StoredReport(
        company_id=current_user.company_id,
        report_type=report_type,
        title=title or report_type,
        filename=filename,
        file_path=path,
        synced=True,
        created_by=current_user.id,
    )
    db.add(rec)
    db.commit()
    db.refresh(rec)
    return {"ok": True, "id": rec.id, "message": "Report synchronised to internal memory"}


@app.get("/api/reports/stored/{rid}/download")
def download_stored_report(
    rid: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    r = db.query(StoredReport).filter(
        StoredReport.id == rid, StoredReport.company_id == current_user.company_id
    ).first()
    if not r:
        raise HTTPException(404)
    p = Path(r.file_path)
    if not p.exists():
        # try STORED_DIR / filename
        p2 = STORED_DIR / r.filename
        if p2.exists():
            p = p2
        else:
            raise HTTPException(404, "File missing from internal storage")
    return FileResponse(str(p), media_type="application/pdf", filename=r.filename)


@app.get("/api/reports/bank-recon/pdf")
def bank_recon_pdf(
    account_id: Optional[int] = None,
    session_id: Optional[int] = None,
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    data = bank_recon_lines(account_id, None, None, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    ticked = [L for L in data["lines"] if L.get("ticked")]
    unticked = [L for L in data["lines"] if not L.get("ticked")]
    sess = None
    if session_id:
        sess = db.query(BankStatementSession).filter(
            BankStatementSession.id == session_id,
            BankStatementSession.company_id == current_user.company_id,
        ).first()
    if not sess:
        sess = db.query(BankStatementSession).filter(
            BankStatementSession.company_id == current_user.company_id
        ).order_by(BankStatementSession.id.desc()).first()
    stmt_bal = float(sess.statement_balance) if sess else float(data["totals"].get("book_balance") or 0)
    book_bal = float(sess.book_balance) if sess else float(data["totals"].get("book_balance") or 0)
    # If book balance not entered, use cashbook running balance after ticks concept
    if sess is None or not sess.book_balance:
        book_bal = float(data["totals"].get("book_balance") or 0)
    charges = float(getattr(sess, "bank_charges", 0) or 0) if sess else 0
    charges_note = getattr(sess, "bank_charges_note", "") or "" if sess else ""
    unp = float(getattr(sess, "unpresented_cheques", 0) or 0) if sess else float(data["totals"].get("outstanding") or 0)
    dep = float(getattr(sess, "deposits_in_transit", 0) or 0) if sess else 0
    stamp = getattr(sess, "approver_stamp", None) if sess else None
    if sess and getattr(sess, "status", "") != "approved":
        # still allow download draft, without stamp
        pass
    kpis = _dashboard_kpis(db, current_user.company_id)
    buf = build_bank_recon_pdf(
        co, stmt_bal, book_bal, charges, charges_note, unp, dep,
        ticked, unticked, code, sym,
        period_label=f"Session #{sess.id}" if sess else "Current reconciliation",
        stamp_text=stamp, kpis=kpis,
    )
    fname = f"bank_reconciliation_{sess.id if sess else 'current'}.pdf"
    path, safe = _save_pdf_bytes(current_user.company_id, current_user.id, "bank_recon", "Bank Reconciliation", fname, buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={
                                 "Content-Disposition": f"attachment; filename={safe}",
                                 "X-Stored-Path": path,
                                 "X-Report-Type": "bank_recon",
                             })


@app.get("/api/reports/trial-balance/pdf")
def trial_balance_pdf(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = trial_balance(current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Code", "Name", "Type", "Project", f"Debit ({sym})", f"Credit ({sym})", "Balance"]
    rows = [[r["code"], r["name"], r["type"], r["project_code"], f"{r['debit']:,.2f}", f"{r['credit']:,.2f}", f"{r['balance']:,.2f}"] for r in data["rows"]]
    foot = [f"Total Debit: {sym}{data['total_debit']:,.2f}", f"Total Credit: {sym}{data['total_credit']:,.2f}",
            "BALANCED" if data["balanced"] else "OUT OF BALANCE"]
    buf = build_pdf(co, "TRIAL BALANCE", headers, rows, code, sym, True, foot)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": "attachment; filename=trial_balance.pdf"})


@app.get("/api/reports/ledger/pdf")
def ledger_pdf(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = general_ledger(current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Entry", "Date", "Source", "Account", "Description", f"Debit ({sym})", f"Credit ({sym})"]
    rows = [[r["entry_no"], r["date"], r["source_type"], r["account"], r["description"], f"{r['debit']:,.2f}", f"{r['credit']:,.2f}"] for r in data]
    buf = build_pdf(co, "GENERAL LEDGER", headers, rows, code, sym, True)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": "attachment; filename=general_ledger.pdf"})


@app.get("/api/reports/budget-variance/pdf")
def variance_pdf(project_code: Optional[str] = None, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = budget_variance(project_code, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Budget Code", "Description", f"Budgeted ({sym})", f"Actual ({sym})", f"Variance ({sym})", "Remark"]
    rows = [[r["budget_code"], r["description"], f"{r['budgeted']:,.2f}", f"{r['actual']:,.2f}", f"{r['variance']:,.2f}", r["remark"]] for r in data["rows"]]
    rows.append(["", "TOTAL", f"{data['total_budget']:,.2f}", f"{data['total_actual']:,.2f}", f"{data['total_variance']:,.2f}", ""])
    buf = build_pdf(co, f"BUDGET VARIANCE — {data['project_code']}", headers, rows, code, sym, True)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": "attachment; filename=budget_variance.pdf"})


@app.get("/api/reports/assets/pdf")
def assets_pdf(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    assets = db.query(Asset).filter(Asset.company_id == current_user.company_id).all()
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Number", "Name", "Category", "Assigned", "Cost", "NBV", "Condition", "Status", "Insurance"]
    rows = [[a.asset_number, a.asset_name, a.category or "", a.assigned_to or "", f"{(a.cost or 0):,.2f}", f"{(a.nbv or 0):,.2f}", a.condition or "", a.status or "", a.insurance or ""] for a in assets]
    buf = build_pdf(co, "FIXED ASSET REGISTER", headers, rows, code, sym, True, kpis=_dashboard_kpis(db, current_user.company_id))
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": "attachment; filename=assets.pdf"})


@app.get("/api/reports/inventory/pdf")
def inventory_pdf(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    items = db.query(InventoryItem).filter(InventoryItem.company_id == current_user.company_id).all()
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Code", "Name", "Category", "Dept", "Cost", "Balance", "Value"]
    rows = [[i.item_code, i.item_name, i.category or "", i.department or "", f"{(i.cost_price or 0):,.2f}", i.balance_qty, f"{(i.total_value or 0):,.2f}"] for i in items]
    buf = build_pdf(co, "INVENTORY REGISTER", headers, rows, code, sym, True, kpis=_dashboard_kpis(db, current_user.company_id))
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": "attachment; filename=inventory.pdf"})


@app.get("/api/reports/vendors/pdf")
def vendors_pdf(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    vendors = db.query(Vendor).filter(Vendor.company_id == current_user.company_id).all()
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["No", "Name", "Tax", "Score", "Amount", "Bank", "Description"]
    rows = [[v.vendor_number, v.name, v.tax_clearance or "", v.score, f"{(v.amount or 0):,.2f}", v.bank or "", (v.description or "")[:40]] for v in vendors]
    buf = build_pdf(co, "VENDOR / PROCUREMENT REGISTER", headers, rows, code, sym, True)
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": "attachment; filename=vendors.pdf"})


@app.get("/api/reports/payments/pdf")
def payments_pdf(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    pays = db.query(PaymentRequest).filter(PaymentRequest.company_id == current_user.company_id).all()
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Request No", "Payee", "Amount", "Status", "Narration"]
    rows = [[p.request_no, p.payee_name or "", f"{p.amount:,.2f}", p.status, (p.narration or "")[:40]] for p in pays]
    buf = build_pdf(co, "PAYMENT REQUESTS", headers, rows, code, sym, True)
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition": "attachment; filename=payments.pdf"})


# Single payment voucher PDF
@app.get("/api/reports/voucher/{pid}/pdf")
def voucher_pdf(pid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr:
        raise HTTPException(404, "Payment request not found")
    if pr.status not in ("finance_approved", "paid", "approved", "program_approved", "submitted"):
        raise HTTPException(400, "Voucher available after submission")
    co, code, sym = _company_and_currency(db, current_user)
    approvers = {}
    if pr.program_approved_by:
        u = db.query(User).filter(User.id == pr.program_approved_by).first()
        approvers["Program approver"] = f"{(u.full_name or u.username) if u else pr.program_approved_by} @ {pr.program_approved_at or ''}"
    if pr.finance_approved_by:
        u = db.query(User).filter(User.id == pr.finance_approved_by).first()
        approvers["Finance approver"] = f"{(u.full_name or u.username) if u else pr.finance_approved_by} @ {pr.finance_approved_at or ''}"
    if pr.designated_approver_id:
        u = db.query(User).filter(User.id == pr.designated_approver_id).first()
        approvers["Designated approver"] = (u.full_name or u.username) if u else str(pr.designated_approver_id)
    kpis = _dashboard_kpis(db, current_user.company_id)
    buf = build_payment_voucher_pdf(co, pr, approvers, code, sym, kpis)
    fname = f"voucher_{pr.request_no}.pdf"
    path, safe = _save_pdf_bytes(current_user.company_id, current_user.id, "payment_voucher", f"Voucher {pr.request_no}", fname, buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename={safe}",
                                      "X-Stored-Path": path, "X-Report-Type": "payment_voucher"})



# ===================== PROJECTS & FINANCIAL STATEMENTS =====================
@app.get("/api/projects")
def list_projects(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(ProjectCode).filter(
        ProjectCode.company_id == current_user.company_id, ProjectCode.is_active == True
    ).order_by(ProjectCode.code).all()
    return [{
        "id": p.id, "code": p.code, "name": p.name, "description": p.description or "",
        "budget_amount": getattr(p, "budget_amount", 0) or 0,
        "start_date": str(p.start_date) if getattr(p, "start_date", None) else None,
        "end_date": str(p.end_date) if getattr(p, "end_date", None) else None,
    } for p in rows]


@app.get("/api/reports/project/{project_id}")
def project_report_data(
    project_id: int,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    p = db.query(ProjectCode).filter(
        ProjectCode.id == project_id, ProjectCode.company_id == current_user.company_id
    ).first()
    if not p:
        raise HTTPException(404, "Project not found")
    q = db.query(JournalEntry).filter(
        JournalEntry.company_id == current_user.company_id,
        JournalEntry.project_code_id == project_id,
    )
    if start_date:
        try: q = q.filter(JournalEntry.entry_date >= date.fromisoformat(start_date))
        except Exception: pass
    if end_date:
        try: q = q.filter(JournalEntry.entry_date <= date.fromisoformat(end_date))
        except Exception: pass
    lines = q.order_by(JournalEntry.entry_date).all()
    payments = db.query(PaymentRequest).filter(
        PaymentRequest.company_id == current_user.company_id,
        PaymentRequest.project_code_id == project_id,
    ).all()
    total_dr = sum(l.debit or 0 for l in lines)
    total_cr = sum(l.credit or 0 for l in lines)
    pay_total = sum(x.amount or 0 for x in payments if x.status in ("paid", "finance_approved", "program_approved", "submitted"))
    return {
        "project": {"id": p.id, "code": p.code, "name": p.name, "budget_amount": getattr(p, "budget_amount", 0) or 0},
        "lines": [{
            "id": l.id, "date": str(l.entry_date), "entry_no": l.entry_no,
            "description": l.description, "debit": l.debit, "credit": l.credit,
            "account_id": l.account_id, "source_type": l.source_type, "source_id": l.source_id,
        } for l in lines],
        "payments": [{
            "id": x.id, "request_no": x.request_no, "amount": x.amount,
            "status": x.status, "payee": x.payee_name,
        } for x in payments],
        "totals": {"debit": total_dr, "credit": total_cr, "payments": pay_total,
                   "budget": getattr(p, "budget_amount", 0) or 0,
                   "variance": (getattr(p, "budget_amount", 0) or 0) - pay_total},
    }


@app.get("/api/reports/project/{project_id}/pdf")
def project_report_pdf(
    project_id: int,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    data = project_report_data(project_id, start_date, end_date, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Date", "Entry", "Description", f"Debit ({sym})", f"Credit ({sym})", "Source"]
    rows = [[L["date"], L["entry_no"], (L["description"] or "")[:40],
             f"{L['debit']:,.2f}", f"{L['credit']:,.2f}",
             f"{L.get('source_type') or ''}:{L.get('source_id') or ''}"] for L in data["lines"]]
    foot = [
        f"Project: {data['project']['code']} — {data['project']['name']}",
        f"Budget: {sym}{data['totals']['budget']:,.2f} | Payments: {sym}{data['totals']['payments']:,.2f} | Variance: {sym}{data['totals']['variance']:,.2f}",
        "Figures are trailable via Entry No / Source on the project report screen.",
    ]
    buf = build_pdf(co, f"PROJECT REPORT — {data['project']['code']}", headers, rows, code, sym, True,
                    foot, description=data["project"]["name"],
                    kpis=_dashboard_kpis(db, current_user.company_id))
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename=project_{data['project']['code']}.pdf"})


def _period_filter(q, start_date, end_date, year):
    if year:
        try:
            y = int(year)
            q = q.filter(JournalEntry.entry_date >= date(y, 1, 1), JournalEntry.entry_date <= date(y, 12, 31))
            return q
        except Exception:
            pass
    if start_date:
        try: q = q.filter(JournalEntry.entry_date >= date.fromisoformat(start_date))
        except Exception: pass
    if end_date:
        try: q = q.filter(JournalEntry.entry_date <= date.fromisoformat(end_date))
        except Exception: pass
    return q


@app.get("/api/reports/financial-position")
def statement_financial_position(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    year: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Statement of Financial Position (Balance Sheet) as at end date / year-end."""
    cid = current_user.company_id
    accounts = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == cid, ChartOfAccount.is_active == True).all()
    assets, liabilities, equity = [], [], []
    ta = tl = te = 0.0
    for a in accounts:
        q = db.query(JournalEntry).filter(JournalEntry.company_id == cid, JournalEntry.account_id == a.id)
        q = _period_filter(q, start_date, end_date, year)
        lines = q.all()
        bal = sum((x.debit or 0) - (x.credit or 0) for x in lines)
        row = {"id": a.id, "code": a.code, "name": a.name, "balance": bal,
               "trail": f"/api/finance/transaction-trail by account {a.id}"}
        t = (a.account_type or "").lower()
        if t in ("asset", "cash", "fixed asset", "inventory"):
            assets.append(row); ta += bal
        elif t in ("liability", "payable"):
            liabilities.append(row); tl += bal
        elif t in ("equity", "capital"):
            equity.append(row); te += bal
        else:
            # net income proxy not classified here
            pass
    return {
        "as_at": end_date or (f"{year}-12-31" if year else str(date.today())),
        "assets": assets, "liabilities": liabilities, "equity": equity,
        "total_assets": ta, "total_liabilities": tl, "total_equity": te,
    }


@app.get("/api/reports/financial-performance")
def statement_financial_performance(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    year: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Statement of Financial Performance (Income Statement / P&L)."""
    cid = current_user.company_id
    accounts = db.query(ChartOfAccount).filter(ChartOfAccount.company_id == cid, ChartOfAccount.is_active == True).all()
    income, expenses = [], []
    ti = te = 0.0
    for a in accounts:
        q = db.query(JournalEntry).filter(JournalEntry.company_id == cid, JournalEntry.account_id == a.id)
        q = _period_filter(q, start_date, end_date, year)
        lines = q.all()
        # income credit-nature, expense debit-nature
        bal = sum((x.credit or 0) - (x.debit or 0) for x in lines)
        t = (a.account_type or "").lower()
        row = {"id": a.id, "code": a.code, "name": a.name, "balance": abs(bal),
               "raw": bal, "trail_hint": f"Account {a.code} journal lines"}
        if t in ("income", "revenue"):
            income.append(row); ti += abs(bal)
        elif t in ("expense", "cost"):
            # expenses: debit - credit
            ebal = sum((x.debit or 0) - (x.credit or 0) for x in lines)
            row["balance"] = ebal
            expenses.append(row); te += ebal
    return {
        "period": {"start": start_date, "end": end_date, "year": year},
        "income": income, "expenses": expenses,
        "total_income": ti, "total_expenses": te, "surplus_deficit": ti - te,
    }


@app.get("/api/reports/cash-flow")
def statement_cash_flow(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    year: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Simplified Statement of Cash Flows from cash account movements."""
    cid = current_user.company_id
    cash_accs = db.query(ChartOfAccount).filter(
        ChartOfAccount.company_id == cid,
        ChartOfAccount.account_type.in_(["Cash", "cash", "Asset"]),
    ).all()
    # Prefer name containing bank/cash
    cash_ids = [a.id for a in cash_accs if "cash" in (a.name or "").lower() or "bank" in (a.name or "").lower() or (a.account_type or "").lower() == "cash"]
    if not cash_ids:
        cash_ids = [a.id for a in cash_accs]
    q = db.query(JournalEntry).filter(JournalEntry.company_id == cid, JournalEntry.account_id.in_(cash_ids or [-1]))
    q = _period_filter(q, start_date, end_date, year)
    lines = q.order_by(JournalEntry.entry_date).all()
    operating = investing = financing = 0.0
    detail = []
    for L in lines:
        net = (L.debit or 0) - (L.credit or 0)
        st = (L.source_type or "").lower()
        bucket = "operating"
        if st in ("asset", "asset_adjustment"):
            bucket = "investing"; investing += net
        elif st in ("equity",):
            bucket = "financing"; financing += net
        else:
            operating += net
        detail.append({
            "id": L.id, "date": str(L.entry_date), "entry_no": L.entry_no,
            "description": L.description, "net": net, "bucket": bucket,
            "source_type": L.source_type, "source_id": L.source_id,
        })
    return {
        "period": {"start": start_date, "end": end_date, "year": year},
        "operating": operating, "investing": investing, "financing": financing,
        "net_change": operating + investing + financing,
        "lines": detail,
    }


def _fs_pdf(title, headers, rows, foot, user, db):
    co, code, sym = _company_and_currency(db, user)
    buf = build_pdf(co, title, headers, rows, code, sym, False, foot,
                    kpis=_dashboard_kpis(db, user.company_id))
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename={title.lower().replace(' ','_')}.pdf"})


@app.get("/api/reports/financial-position/pdf")
def sfp_pdf(start_date: Optional[str] = None, end_date: Optional[str] = None, year: Optional[int] = None,
            current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = statement_financial_position(start_date, end_date, year, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    rows = [["ASSETS", "", ""]]
    for a in data["assets"]:
        rows.append([a["code"], a["name"], f"{a['balance']:,.2f}"])
    rows.append(["Total assets", "", f"{data['total_assets']:,.2f}"])
    rows.append(["LIABILITIES", "", ""])
    for a in data["liabilities"]:
        rows.append([a["code"], a["name"], f"{a['balance']:,.2f}"])
    rows.append(["Total liabilities", "", f"{data['total_liabilities']:,.2f}"])
    rows.append(["EQUITY", "", ""])
    for a in data["equity"]:
        rows.append([a["code"], a["name"], f"{a['balance']:,.2f}"])
    rows.append(["Total equity", "", f"{data['total_equity']:,.2f}"])
    return _fs_pdf("STATEMENT OF FINANCIAL POSITION", ["Code", "Account", f"Amount ({sym})"], rows,
                   [f"As at {data['as_at']}", "Click trail on screen for source journals"], current_user, db)


@app.get("/api/reports/financial-performance/pdf")
def sfpn_pdf(start_date: Optional[str] = None, end_date: Optional[str] = None, year: Optional[int] = None,
             current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = statement_financial_performance(start_date, end_date, year, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    rows = [["INCOME", "", ""]]
    for a in data["income"]:
        rows.append([a["code"], a["name"], f"{a['balance']:,.2f}"])
    rows.append(["Total income", "", f"{data['total_income']:,.2f}"])
    rows.append(["EXPENSES", "", ""])
    for a in data["expenses"]:
        rows.append([a["code"], a["name"], f"{a['balance']:,.2f}"])
    rows.append(["Total expenses", "", f"{data['total_expenses']:,.2f}"])
    rows.append(["Surplus / (Deficit)", "", f"{data['surplus_deficit']:,.2f}"])
    return _fs_pdf("STATEMENT OF FINANCIAL PERFORMANCE", ["Code", "Account", f"Amount ({sym})"], rows,
                   ["Trail each line on-screen to journal source"], current_user, db)


@app.get("/api/reports/cash-flow/pdf")
def scf_pdf(start_date: Optional[str] = None, end_date: Optional[str] = None, year: Optional[int] = None,
            current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = statement_cash_flow(start_date, end_date, year, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    rows = [
        ["Operating activities", f"{data['operating']:,.2f}"],
        ["Investing activities", f"{data['investing']:,.2f}"],
        ["Financing activities", f"{data['financing']:,.2f}"],
        ["Net change in cash", f"{data['net_change']:,.2f}"],
    ]
    return _fs_pdf("STATEMENT OF CASH FLOWS", ["Particulars", f"Amount ({sym})"], rows,
                   ["Detail lines trailable on the Cash Flow report page"], current_user, db)


@app.patch("/api/payments/{pid}/accounts")
def finance_change_accounts(
    pid: int,
    debit_account_id: Optional[int] = Form(None),
    credit_account_id: Optional[int] = Form(None),
    project_code_id: Optional[int] = Form(None),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    """Finance can change COA codes on a request awaiting finance approval."""
    pr = db.query(PaymentRequest).filter(
        PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id
    ).first()
    if not pr:
        raise HTTPException(404)
    if pr.status not in ("submitted", "program_approved", "returned", "finance_approved"):
        raise HTTPException(400, "Only open / program-approved requests can be adjusted")
    if debit_account_id is not None:
        pr.debit_account_id = debit_account_id
    if credit_account_id is not None:
        pr.credit_account_id = credit_account_id
    if project_code_id is not None:
        pr.project_code_id = project_code_id
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="accounts_updated", comment="Account codes updated by finance"))
    db.commit()
    return {"ok": True, "debit_account_id": pr.debit_account_id, "credit_account_id": pr.credit_account_id}


@app.post("/api/payments/{pid}/request-correction")
def payment_request_correction(
    pid: int,
    message: str = Form(...),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    """Finance messages originator to correct and resubmit the payment request."""
    pr = db.query(PaymentRequest).filter(
        PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id
    ).first()
    if not pr:
        raise HTTPException(404)
    if pr.status not in ("submitted", "program_approved", "returned", "finance_approved"):
        raise HTTPException(400, "Cannot request correction on this status")
    pr.status = "returned"
    pr.rejection_reason = message
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="request_correction", comment=message))
    # Also create correction-style inbox message to requester
    db.add(CorrectionRequest(
        company_id=current_user.company_id,
        journal_entry_id=None,
        source_type="payment",
        source_id=pr.id,
        from_user_id=current_user.id,
        to_user_id=pr.requester_id,
        message=f"Payment {pr.request_no}: {message}",
        status="open",
    ))
    db.commit()
    return {"ok": True, "message": "Originator notified to correct and resubmit", "status": "returned"}


@app.post("/api/payments/{pid}/resubmit")
def payment_resubmit(
    pid: int,
    amount: Optional[float] = Form(None),
    narration: Optional[str] = Form(None),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    pr = db.query(PaymentRequest).filter(
        PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id
    ).first()
    if not pr:
        raise HTTPException(404)
    if pr.requester_id != current_user.id and current_user.role not in ("company_admin",):
        raise HTTPException(403, "Only the originator can resubmit")
    if pr.status != "returned":
        raise HTTPException(400, "Only returned requests can be resubmitted")
    if amount is not None:
        pr.amount = amount
        pr.amount_in_words = amount_to_words(amount)
    if narration is not None:
        pr.narration = narration
    pr.status = "submitted"
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="resubmit", comment="Resubmitted after correction"))
    db.commit()
    return {"ok": True, "status": "submitted"}



# ===================== PROCUREMENT (RFQ / quotes / scoring) =====================
@app.get("/api/procurement/services")
def list_proc_services(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    return db.query(ProcurementService).filter(
        ProcurementService.company_id == current_user.company_id, ProcurementService.is_active == True
    ).order_by(ProcurementService.code).all()


@app.post("/api/procurement/services")
def create_proc_service(
    code: str = Form(...), name: str = Form(...), description: str = Form(""),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    row = ProcurementService(company_id=current_user.company_id, code=code, name=name, description=description)
    db.add(row); db.commit(); db.refresh(row)
    return row


@app.get("/api/procurement/rfqs")
def list_rfqs(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == current_user.company_id).order_by(ProcurementRFQ.id.desc()).all()
    out = []
    for r in rows:
        svc = db.query(ProcurementService).filter(ProcurementService.id == r.service_id).first() if r.service_id else None
        da = db.query(ChartOfAccount).filter(ChartOfAccount.id == r.debit_account_id).first() if r.debit_account_id else None
        ca = db.query(ChartOfAccount).filter(ChartOfAccount.id == r.credit_account_id).first() if r.credit_account_id else None
        out.append({
            "id": r.id, "rfq_no": r.rfq_no, "title": r.title, "status": r.status,
            "description": r.description, "service": f"{svc.code} — {svc.name}" if svc else "",
            "debit_account": f"{da.code} — {da.name}" if da else "",
            "credit_account": f"{ca.code} — {ca.name}" if ca else "",
            "debit_account_id": r.debit_account_id, "credit_account_id": r.credit_account_id,
            "project_code_id": r.project_code_id, "created_at": str(r.created_at) if r.created_at else None,
        })
    return out


@app.post("/api/procurement/rfqs")
def create_rfq(
    title: str = Form(...),
    description: str = Form(""),
    service_id: Optional[int] = Form(None),
    committee_id: Optional[int] = Form(None),
    debit_account_id: Optional[int] = Form(None),
    credit_account_id: Optional[int] = Form(None),
    project_code_id: Optional[int] = Form(None),
    current_user: User = Depends(require_roles("finance", "company_admin", "program")),
    db: Session = Depends(get_db),
):
    n = db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == current_user.company_id).count() + 1
    row = ProcurementRFQ(
        company_id=current_user.company_id,
        rfq_no=f"RFQ-{n:04d}",
        title=title, description=description, service_id=service_id,
        committee_id=committee_id,
        requesting_officer_id=current_user.id,
        debit_account_id=debit_account_id, credit_account_id=credit_account_id,
        project_code_id=project_code_id, created_by=current_user.id, status="open",
    )
    db.add(row); db.commit(); db.refresh(row)
    return row


@app.get("/api/procurement/rfqs/{rid}/quotes")
def list_quotes(rid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    return db.query(ProcurementQuote).filter(
        ProcurementQuote.company_id == current_user.company_id, ProcurementQuote.rfq_id == rid
    ).order_by(ProcurementQuote.final_score.desc()).all()


@app.post("/api/procurement/rfqs/{rid}/quotes")
def submit_quote(
    rid: int,
    vendor_id: Optional[int] = Form(None),
    vendor_name: str = Form(""),
    amount: float = Form(...),
    tax_amount: float = Form(0),
    delivery_days: int = Form(0),
    notes: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    if not rfq:
        raise HTTPException(404)
    total = float(amount) + float(tax_amount or 0)
    # system score: lower price ranks higher among quotes later recalculated
    q = ProcurementQuote(
        company_id=current_user.company_id, rfq_id=rid, vendor_id=vendor_id,
        vendor_name=vendor_name, amount=amount, tax_amount=tax_amount, total_amount=total,
        delivery_days=delivery_days, notes=notes, status="submitted",
    )
    db.add(q); db.commit(); db.refresh(q)
    _rescore_rfq(db, rid)
    return q


def _rescore_rfq(db, rid):
    quotes = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rid).all()
    if not quotes:
        return
    totals = [q.total_amount or 0 for q in quotes]
    mn, mx = min(totals), max(totals)
    for q in quotes:
        if mx > mn:
            # cheaper = higher system score out of 40
            price_score = 40 * (1 - ((q.total_amount or 0) - mn) / (mx - mn))
        else:
            price_score = 40.0
        q.system_score = round(price_score, 2)
        q.final_score = round((q.system_score or 0) + (q.committee_score or 0), 2)
        db.add(q)
    db.commit()


@app.post("/api/procurement/quotes/{qid}/committee-score")
def committee_score(
    qid: int,
    score: float = Form(...),  # 0-60
    current_user: User = Depends(require_roles("finance", "company_admin", "program")),
    db: Session = Depends(get_db),
):
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == qid, ProcurementQuote.company_id == current_user.company_id).first()
    if not q:
        raise HTTPException(404)
    q.committee_score = max(0, min(60, float(score)))
    q.final_score = round((q.system_score or 0) + (q.committee_score or 0), 2)
    q.status = "scored"
    db.add(q); db.commit()
    _rescore_rfq(db, q.rfq_id)
    return {"ok": True, "final_score": q.final_score}


@app.post("/api/procurement/rfqs/{rid}/award")
def award_rfq(
    rid: int,
    quote_id: int = Form(...),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == quote_id, ProcurementQuote.rfq_id == rid).first()
    if not rfq or not q:
        raise HTTPException(404)
    for other in db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rid).all():
        other.status = "winner" if other.id == quote_id else "rejected"
        db.add(other)
    rfq.status = "awarded"
    db.add(rfq)
    # post commitment if accounts set
    if rfq.debit_account_id and rfq.credit_account_id and (q.total_amount or 0) > 0:
        post_double_entry(
            db, current_user.company_id, current_user.id, "vendor", q.vendor_id,
            f"Award {rfq.rfq_no}", q.vendor_name or rfq.title,
            rfq.debit_account_id, rfq.credit_account_id, q.total_amount, rfq.project_code_id,
        )
    db.commit()
    return {"ok": True, "message": f"Awarded to {q.vendor_name}"}


@app.get("/api/finance/coa/options")
def coa_options(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Lightweight list for all dropdowns: id, label with code."""
    rows = db.query(ChartOfAccount).filter(
        ChartOfAccount.company_id == current_user.company_id,
        ChartOfAccount.is_active == True,
    ).order_by(ChartOfAccount.code).all()
    return [{"id": a.id, "code": a.code, "name": a.name, "type": a.account_type,
             "label": f"{a.code} — {a.name} ({a.account_type})"} for a in rows]



# ===================== COMMITTEE + PO + ARCHIVES =====================
@app.get("/api/procurement/committees")
def list_committees(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(ProcurementCommittee).filter(
        ProcurementCommittee.company_id == current_user.company_id, ProcurementCommittee.is_active == True
    ).order_by(ProcurementCommittee.name).all()
    out = []
    for c in rows:
        members = db.query(ProcurementCommitteeMember).filter(
            ProcurementCommitteeMember.committee_id == c.id, ProcurementCommitteeMember.is_active == True
        ).all()
        out.append({
            "id": c.id, "name": c.name, "description": c.description or "",
            "members": [{"id": m.id, "name": m.member_name, "role": m.role_title, "user_id": m.user_id} for m in members],
        })
    return out


@app.post("/api/procurement/committees")
def create_committee(
    name: str = Form(...), description: str = Form(""),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    c = ProcurementCommittee(company_id=current_user.company_id, name=name, description=description)
    db.add(c); db.commit(); db.refresh(c)
    return c


@app.post("/api/procurement/committees/{cid}/members")
def add_committee_member(
    cid: int,
    member_name: str = Form(...),
    role_title: str = Form("Member"),
    user_id: Optional[int] = Form(None),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    c = db.query(ProcurementCommittee).filter(ProcurementCommittee.id == cid, ProcurementCommittee.company_id == current_user.company_id).first()
    if not c:
        raise HTTPException(404)
    m = ProcurementCommitteeMember(committee_id=cid, member_name=member_name, role_title=role_title, user_id=user_id)
    db.add(m); db.commit(); db.refresh(m)
    return m


@app.post("/api/procurement/quotes/{qid}/member-score")
def member_score_quote(
    qid: int,
    member_id: int = Form(...),
    score: float = Form(...),
    comment: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == qid, ProcurementQuote.company_id == current_user.company_id).first()
    if not q:
        raise HTTPException(404)
    sc = max(0.0, min(60.0, float(score)))
    existing = db.query(QuoteMemberScore).filter(QuoteMemberScore.quote_id == qid, QuoteMemberScore.member_id == member_id).first()
    if existing:
        existing.score = sc; existing.comment = comment; existing.scored_at = datetime.utcnow()
        db.add(existing)
    else:
        db.add(QuoteMemberScore(quote_id=qid, member_id=member_id, score=sc, comment=comment))
    db.commit()
    # average member scores → committee_score (0-60)
    scores = db.query(QuoteMemberScore).filter(QuoteMemberScore.quote_id == qid).all()
    if scores:
        avg = sum(s.score or 0 for s in scores) / len(scores)
        q.committee_score = round(avg, 2)
        q.final_score = round((q.system_score or 0) + (q.committee_score or 0), 2)
        q.status = "scored"
        db.add(q); db.commit()
    return {"ok": True, "committee_score": q.committee_score, "final_score": q.final_score, "members_scored": len(scores)}


@app.post("/api/procurement/rfqs/{rid}/award-with-po")
def award_with_po(
    rid: int,
    quote_id: int = Form(...),
    current_user: User = Depends(require_roles("finance", "company_admin")),
    db: Session = Depends(get_db),
):
    """Committee approval: award winner, create PO for requesting officer review."""
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == quote_id, ProcurementQuote.rfq_id == rid).first()
    if not rfq or not q:
        raise HTTPException(404)
    for other in db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rid).all():
        other.status = "winner" if other.id == quote_id else "rejected"
        db.add(other)
    rfq.status = "awarded"
    db.add(rfq)
    n = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == current_user.company_id).count() + 1
    po = PurchaseOrder(
        company_id=current_user.company_id,
        po_no=f"PO-{n:04d}",
        rfq_id=rid, quote_id=quote_id,
        vendor_id=q.vendor_id, vendor_name=q.vendor_name or "",
        amount=q.total_amount or q.amount or 0,
        description=f"{rfq.title} — {rfq.rfq_no}",
        status="pending_officer",
        requesting_officer_id=rfq.requesting_officer_id or rfq.created_by,
        debit_account_id=rfq.debit_account_id, credit_account_id=rfq.credit_account_id,
        project_code_id=rfq.project_code_id,
        approved_at=datetime.utcnow(), created_by=current_user.id,
    )
    db.add(po); db.commit(); db.refresh(po)
    return {"ok": True, "po_id": po.id, "po_no": po.po_no, "message": f"PO {po.po_no} created for requesting officer"}


@app.get("/api/procurement/purchase-orders")
def list_pos(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    q = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == current_user.company_id)
    # officers see theirs; finance/admin see all
    if current_user.role not in ("finance", "company_admin", "superadmin"):
        q = q.filter(
            (PurchaseOrder.requesting_officer_id == current_user.id) | (PurchaseOrder.created_by == current_user.id)
        )
    rows = q.order_by(PurchaseOrder.id.desc()).all()
    return [{
        "id": p.id, "po_no": p.po_no, "vendor_name": p.vendor_name, "amount": p.amount,
        "description": p.description, "status": p.status, "rfq_id": p.rfq_id,
        "payment_request_id": p.payment_request_id,
        "created_at": str(p.created_at) if p.created_at else None,
    } for p in rows]


@app.post("/api/procurement/purchase-orders/{poid}/submit-payment")
def po_submit_payment(
    poid: int,
    budget_code_id: int = Form(...),
    expense_code_id: int = Form(...),
    designated_approver_id: int = Form(...),
    narration: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Requesting officer reviews PO and submits into payment approval workflow."""
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == poid, PurchaseOrder.company_id == current_user.company_id).first()
    if not po:
        raise HTTPException(404)
    if po.status not in ("pending_officer",):
        raise HTTPException(400, "PO already submitted or closed")
    if po.requesting_officer_id and po.requesting_officer_id != current_user.id and current_user.role not in ("finance", "company_admin"):
        raise HTTPException(403, "Only the requesting officer can submit this PO")
    n = db.query(PaymentRequest).filter(PaymentRequest.company_id == current_user.company_id).count() + 1
    words = amount_to_words(po.amount or 0)
    pr = PaymentRequest(
        company_id=current_user.company_id,
        request_no=f"PR-PO-{n:04d}",
        requester_id=current_user.id,
        budget_code_id=budget_code_id,
        expense_code_id=expense_code_id,
        project_code_id=po.project_code_id,
        amount=po.amount or 0,
        amount_in_words=words,
        narration=narration or po.description or "",
        payee_name=po.vendor_name or "",
        debit_account_id=po.debit_account_id,
        credit_account_id=po.credit_account_id,
        designated_approver_id=designated_approver_id,
        status="submitted",
    )
    db.add(pr); db.commit(); db.refresh(pr)
    po.status = "submitted_payment"
    po.payment_request_id = pr.id
    db.add(po)
    db.add(PaymentApprovalLog(payment_request_id=pr.id, actor_id=current_user.id, action="submit_from_po", comment=f"From {po.po_no}"))
    db.commit()
    return {"ok": True, "payment_request_id": pr.id, "request_no": pr.request_no, "message": "Submitted to payment approval workflow"}


@app.get("/api/procurement/rfqs/{rid}/committee-report")
def committee_report(rid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    if not rfq:
        raise HTTPException(404)
    quotes = db.query(ProcurementQuote).filter(ProcurementQuote.rfq_id == rid).order_by(ProcurementQuote.final_score.desc()).all()
    committee = None
    members = []
    if getattr(rfq, "committee_id", None):
        committee = db.query(ProcurementCommittee).filter(ProcurementCommittee.id == rfq.committee_id).first()
        members = db.query(ProcurementCommitteeMember).filter(ProcurementCommitteeMember.committee_id == rfq.committee_id).all()
    detail = []
    for q in quotes:
        ms = db.query(QuoteMemberScore).filter(QuoteMemberScore.quote_id == q.id).all()
        detail.append({
            "quote_id": q.id, "vendor": q.vendor_name, "total": q.total_amount,
            "system_score": q.system_score, "committee_score": q.committee_score,
            "final_score": q.final_score, "status": q.status,
            "member_scores": [{"member_id": s.member_id, "score": s.score, "comment": s.comment} for s in ms],
        })
    return {
        "rfq": {"id": rfq.id, "rfq_no": rfq.rfq_no, "title": rfq.title, "status": rfq.status},
        "committee": {"id": committee.id, "name": committee.name} if committee else None,
        "members": [{"id": m.id, "name": m.member_name, "role": m.role_title} for m in members],
        "quotes": detail,
    }


@app.get("/api/procurement/rfqs/{rid}/committee-report/pdf")
def committee_report_pdf(rid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    data = committee_report(rid, current_user, db)
    co, code, sym = _company_and_currency(db, current_user)
    headers = ["Vendor", "Total", "System 40", "Committee 60", "Final", "Status"]
    rows = [[q["vendor"], f"{q['total']:,.2f}", q["system_score"], q["committee_score"], q["final_score"], q["status"]] for q in data["quotes"]]
    foot = [
        f"RFQ: {data['rfq']['rfq_no']} — {data['rfq']['title']}",
        f"Committee: {(data['committee'] or {}).get('name') or '—'}",
        "Member scores form the committee component (average, max 60).",
    ]
    buf = build_pdf(co, "PROCUREMENT COMMITTEE REPORT", headers, rows, code, sym, True, foot,
                    kpis=_dashboard_kpis(db, current_user.company_id))
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename=committee_report_{data['rfq']['rfq_no']}.pdf"})


@app.post("/api/procurement/rfqs/{rid}/documents")
async def upload_proc_doc(
    rid: int,
    file: UploadFile = File(...),
    doc_type: str = Form("support"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    if not rfq:
        raise HTTPException(404)
    data = await file.read()
    dest_dir = ARCHIVE_DIR / f"rfq_{rid}"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = f"{secrets.token_hex(4)}_{file.filename}"
    path = dest_dir / safe
    path.write_bytes(data)
    doc = ProcurementDocument(
        company_id=current_user.company_id, rfq_id=rid, filename=file.filename,
        stored_path=str(path), content_type=file.content_type or "application/octet-stream",
        size_bytes=len(data), doc_type=doc_type, uploaded_by=current_user.id,
    )
    db.add(doc); db.commit(); db.refresh(doc)
    return {"id": doc.id, "filename": doc.filename}


@app.get("/api/procurement/rfqs/{rid}/archive.zip")
def procurement_archive(rid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """ZIP of all documents for this procurement + committee report PDF."""
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    if not rfq:
        raise HTTPException(404)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        docs = db.query(ProcurementDocument).filter(ProcurementDocument.rfq_id == rid).all()
        for d in docs:
            p = Path(d.stored_path)
            if p.exists():
                zf.write(p, arcname=f"documents/{d.filename}")
        # embed committee report
        try:
            from reports import build_pdf
            data = committee_report(rid, current_user, db)
            co, code, sym = _company_and_currency(db, current_user)
            headers = ["Vendor", "Total", "System", "Committee", "Final", "Status"]
            rows = [[q["vendor"], q["total"], q["system_score"], q["committee_score"], q["final_score"], q["status"]] for q in data["quotes"]]
            pdfbuf = build_pdf(co, "COMMITTEE REPORT", headers, rows, code, sym, True, kpis=_dashboard_kpis(db, current_user.company_id))
            zf.writestr(f"committee_report_{rfq.rfq_no}.pdf", pdfbuf.getvalue())
        except Exception as e:
            zf.writestr("committee_report_error.txt", str(e))
        # PO if any
        pos = db.query(PurchaseOrder).filter(PurchaseOrder.rfq_id == rid).all()
        for po in pos:
            zf.writestr(f"po_{po.po_no}.txt", f"PO {po.po_no}\nVendor: {po.vendor_name}\nAmount: {po.amount}\nStatus: {po.status}\n{po.description}")
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f"attachment; filename=procurement_archive_{rfq.rfq_no}.zip"})


@app.get("/api/payments/{pid}/archive.zip")
def payment_archive(pid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """ZIP: payment voucher PDF + all support attachments."""
    pr = db.query(PaymentRequest).filter(PaymentRequest.id == pid, PaymentRequest.company_id == current_user.company_id).first()
    if not pr:
        raise HTTPException(404)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # voucher
        try:
            co, code, sym = _company_and_currency(db, current_user)
            approvers = {}
            if pr.program_approved_by:
                u = db.query(User).filter(User.id == pr.program_approved_by).first()
                approvers["Program"] = (u.full_name or u.username) if u else str(pr.program_approved_by)
            if pr.finance_approved_by:
                u = db.query(User).filter(User.id == pr.finance_approved_by).first()
                approvers["Finance"] = (u.full_name or u.username) if u else str(pr.finance_approved_by)
            vbuf = build_payment_voucher_pdf(co, pr, approvers, code, sym, _dashboard_kpis(db, current_user.company_id))
            zf.writestr(f"voucher_{pr.request_no}.pdf", vbuf.getvalue())
        except Exception as e:
            zf.writestr("voucher_error.txt", str(e))
        atts = db.query(PaymentAttachment).filter(PaymentAttachment.payment_request_id == pid).all()
        for a in atts:
            p = Path(a.stored_path)
            if p.exists():
                zf.writestr(f"attachments/{a.filename}", p.read_bytes())
            else:
                # try relative
                p2 = UPLOADS_DIR / Path(a.stored_path).name
                if p2.exists():
                    zf.writestr(f"attachments/{a.filename}", p2.read_bytes())
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f"attachment; filename=payment_archive_{pr.request_no}.zip"})


@app.get("/manifest.webmanifest")
@app.get("/manifest.json")
def pwa_manifest():
    for p in (
        STATIC_DIR / "manifest.webmanifest",
        FRONTEND_DIR / "manifest.webmanifest",
        STATIC_DIR / "manifest.json",
    ):
        if p.exists():
            return FileResponse(str(p), media_type="application/manifest+json", headers={"Cache-Control": "no-cache"})
    raise HTTPException(404, "manifest not found")


@app.get("/sw.js")
def pwa_sw():
    for p in (STATIC_DIR / "sw.js", FRONTEND_DIR / "sw.js"):
        if p.exists():
            return FileResponse(str(p), media_type="application/javascript", headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})
    raise HTTPException(404, "sw not found")


@app.head("/manifest.webmanifest")
@app.head("/manifest.json")
def pwa_manifest_head():
    return pwa_manifest()



# ===== Robust procurement: mandatory docs, validation, GRN, invoice → finance =====

MANDATORY_BID_DOCS = {
    "Lot 1 FP Commodities": ["cac", "tax_clearance", "nafdac", "maf", "shelf_life_commitment", "sop_recall", "technical_proposal", "financial_proposal", "experience_letter"],
    "Lot 2 Medical Consumables": ["cac", "tax_clearance", "nafdac", "maf", "iso_cert", "pcn_license", "shelf_life_commitment", "technical_proposal", "financial_proposal", "experience_letter", "logistics_proof"],
    "default": ["cac", "tax_clearance", "technical_proposal", "financial_proposal"],
}

@app.post("/api/procurement/quotes/{qid}/upload-doc")
async def upload_bid_document(
    qid: int,
    doc_type: str = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Vendor / staff uploads a mandatory PDF for a bid. Only PDF accepted."""
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == qid, ProcurementQuote.company_id == current_user.company_id).first()
    if not q:
        raise HTTPException(404, "Quote not found")
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF documents are accepted")
    content = await file.read()
    if len(content) > 16 * 1024 * 1024:
        raise HTTPException(400, "File too large (max 16MB)")
    dest_dir = UPLOADS_DIR / f"company_{current_user.company_id}" / "procurement" / f"quote_{qid}"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = secure_filename(file.filename)
    stored = dest_dir / f"{doc_type}_{safe}"
    stored.write_bytes(content)
    doc = ProcurementDocument(
        company_id=current_user.company_id, quote_id=qid, vendor_id=q.vendor_id,
        filename=safe, stored_path=str(stored), content_type="application/pdf",
        size_bytes=len(content), doc_type=doc_type, is_mandatory=True,
        uploaded_by=current_user.id,
    )
    db.add(doc)
    db.commit()
    return {"ok": True, "doc_id": doc.id, "doc_type": doc_type, "filename": safe}


@app.get("/api/procurement/quotes/{qid}/docs-checklist")
def bid_docs_checklist(qid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Return required vs uploaded docs and whether submission is allowed."""
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == qid, ProcurementQuote.company_id == current_user.company_id).first()
    if not q:
        raise HTTPException(404)
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == q.rfq_id).first()
    lot = (rfq.lot if rfq else "") or "default"
    required = MANDATORY_BID_DOCS.get(lot, MANDATORY_BID_DOCS["default"])
    uploaded = db.query(ProcurementDocument).filter(ProcurementDocument.quote_id == qid).all()
    have = {d.doc_type for d in uploaded}
    missing = [r for r in required if r not in have]
    complete = len(missing) == 0 and q.shelf_life_commitment and q.manufacturer_auth
    return {
        "quote_id": qid, "lot": lot, "required": required, "uploaded": list(have),
        "missing": missing, "mandatory_docs_complete": complete,
        "shelf_life_commitment": q.shelf_life_commitment,
        "manufacturer_auth": q.manufacturer_auth,
        "can_submit": complete and q.status in ("draft", "submitted"),
    }


@app.post("/api/procurement/quotes/{qid}/submit")
def submit_bid_with_validation(qid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Hard gate: all mandatory requirements must be met before status becomes submitted."""
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == qid, ProcurementQuote.company_id == current_user.company_id).first()
    if not q:
        raise HTTPException(404)
    check = bid_docs_checklist(qid, current_user, db)
    if not check["can_submit"]:
        raise HTTPException(400, detail={
            "message": "Cannot submit: mandatory requirements incomplete",
            "missing_docs": check["missing"],
            "shelf_life_commitment": check["shelf_life_commitment"],
            "manufacturer_auth": check["manufacturer_auth"],
        })
    q.status = "submitted"
    q.mandatory_docs_complete = True
    q.submitted_at = datetime.utcnow()
    q.preliminary_pass = True  # docs gate passed
    db.commit()
    return {"ok": True, "status": q.status, "message": "Bid submitted – pending preliminary & technical evaluation"}


@app.post("/api/procurement/quotes/{qid}/evaluate-technical")
def evaluate_technical(
    qid: int,
    pass_fail: bool = Form(...),
    score: float = Form(0),
    comment: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Committee records technical Pass/Fail (TOR methodology)."""
    q = db.query(ProcurementQuote).filter(ProcurementQuote.id == qid, ProcurementQuote.company_id == current_user.company_id).first()
    if not q:
        raise HTTPException(404)
    if q.status not in ("submitted", "preliminary", "technical"):
        raise HTTPException(400, "Quote not in evaluable status")
    q.technical_pass = pass_fail
    q.technical_score = score
    q.status = "technical" if pass_fail else "rejected"
    if not pass_fail:
        q.notes = (q.notes or "") + f"\nTechnical reject: {comment}"
    db.commit()
    return {"ok": True, "technical_pass": pass_fail, "status": q.status}


@app.post("/api/procurement/rfqs/{rid}/rank-financial")
def rank_financial(rid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Among technical_pass=True quotes, rank by total_amount ascending (lowest price wins)."""
    rfq = db.query(ProcurementRFQ).filter(ProcurementRFQ.id == rid, ProcurementRFQ.company_id == current_user.company_id).first()
    if not rfq:
        raise HTTPException(404)
    quotes = db.query(ProcurementQuote).filter(
        ProcurementQuote.rfq_id == rid, ProcurementQuote.technical_pass == True
    ).order_by(ProcurementQuote.total_amount.asc()).all()
    for i, q in enumerate(quotes, 1):
        q.financial_rank = i
        q.status = "financial"
        if i == 1:
            q.final_score = max(q.final_score, 90)
    rfq.status = "financial_eval"
    db.commit()
    return {"ok": True, "ranked": [{"id": q.id, "vendor": q.vendor_name, "total": q.total_amount, "rank": q.financial_rank} for q in quotes]}


@app.post("/api/procurement/pos/{poid}/goods-receipt")
def create_goods_receipt(
    poid: int,
    quantities_ok: bool = Form(...),
    package_integrity_ok: bool = Form(...),
    shelf_life_ok: bool = Form(...),
    regulatory_docs_ok: bool = Form(...),
    storage_guidance_received: bool = Form(...),
    received_by: str = Form(""),
    notes: str = Form(""),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Delivery acceptance: ALL conditions must be True for acceptance."""
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == poid, PurchaseOrder.company_id == current_user.company_id).first()
    if not po:
        raise HTTPException(404)
    all_ok = all([quantities_ok, package_integrity_ok, shelf_life_ok, regulatory_docs_ok, storage_guidance_received])
    n = db.query(GoodsReceipt).filter(GoodsReceipt.company_id == current_user.company_id).count() + 1
    grn = GoodsReceipt(
        company_id=current_user.company_id, po_id=poid, grn_no=f"GRN-{n:04d}",
        received_by=received_by or (current_user.full_name or current_user.username),
        quantities_ok=quantities_ok, package_integrity_ok=package_integrity_ok,
        shelf_life_ok=shelf_life_ok, regulatory_docs_ok=regulatory_docs_ok,
        storage_guidance_received=storage_guidance_received, all_conditions_met=all_ok,
        status="accepted" if all_ok else "rejected",
        rejection_reason="" if all_ok else "One or more delivery conditions not met",
        notes=notes, accepted_by_user_id=current_user.id if all_ok else None,
        accepted_at=datetime.utcnow() if all_ok else None,
    )
    db.add(grn); db.commit(); db.refresh(grn)
    return {"ok": True, "grn_id": grn.id, "grn_no": grn.grn_no, "all_conditions_met": all_ok, "status": grn.status}


@app.post("/api/procurement/invoices")
def create_procurement_invoice(
    po_id: int = Form(...),
    grn_id: int = Form(None),
    invoice_no: str = Form(...),
    amount: float = Form(...),
    tax_amount: float = Form(0),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Final invoice after accepted GRN – routes to Finance."""
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.company_id == current_user.company_id).first()
    if not po:
        raise HTTPException(404)
    if grn_id:
        grn = db.query(GoodsReceipt).filter(GoodsReceipt.id == grn_id, GoodsReceipt.all_conditions_met == True).first()
        if not grn:
            raise HTTPException(400, "GRN must exist and have all conditions met before invoice")
    inv = ProcurementInvoice(
        company_id=current_user.company_id, po_id=po_id, grn_id=grn_id,
        invoice_no=invoice_no, amount=amount, tax_amount=tax_amount,
        total_amount=amount + tax_amount, status="received",
        submitted_to_finance_at=datetime.utcnow(),
    )
    db.add(inv); db.commit(); db.refresh(inv)
    return {"ok": True, "invoice_id": inv.id, "status": inv.status, "message": "Invoice received and queued for Finance review"}


@app.get("/api/procurement/invoices")
def list_procurement_invoices(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    rows = db.query(ProcurementInvoice).filter(ProcurementInvoice.company_id == current_user.company_id).order_by(ProcurementInvoice.id.desc()).all()
    return [{"id": r.id, "invoice_no": r.invoice_no, "po_id": r.po_id, "amount": r.total_amount, "status": r.status,
             "submitted_to_finance_at": r.submitted_to_finance_at.isoformat() if r.submitted_to_finance_at else None} for r in rows]


@app.post("/api/procurement/invoices/{iid}/to-finance")
def invoice_to_finance(iid: int, current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Promote invoice to a Payment Request in Finance module."""
    inv = db.query(ProcurementInvoice).filter(ProcurementInvoice.id == iid, ProcurementInvoice.company_id == current_user.company_id).first()
    if not inv:
        raise HTTPException(404)
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == inv.po_id).first()
    n = db.query(PaymentRequest).filter(PaymentRequest.company_id == current_user.company_id).count() + 1
    pr = PaymentRequest(
        company_id=current_user.company_id, request_no=f"PR-INV-{n:04d}",
        description=f"Payment for procurement invoice {inv.invoice_no} / PO {po.po_no if po else inv.po_id}",
        amount=inv.total_amount, status="draft",
        requested_by=current_user.id, debit_account_id=po.debit_account_id if po else None,
        credit_account_id=po.credit_account_id if po else None, project_code_id=po.project_code_id if po else None,
    )
    db.add(pr); db.flush()
    inv.payment_request_id = pr.id
    inv.status = "approved_for_payment"
    if po:
        po.status = "submitted_payment"
        po.payment_request_id = pr.id
    db.commit()
    return {"ok": True, "payment_request_id": pr.id, "request_no": pr.request_no, "invoice_status": inv.status}


@app.delete("/api/procurement/demo-data")
def delete_demo_procurement(current_user: User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    """Bulk-delete all is_demo=True procurement records for the company."""
    if current_user.role not in ("company_admin", "superadmin", "admin"):
        raise HTTPException(403, "Admin only")
    cid = current_user.company_id
    db.query(ProcurementInvoice).filter(ProcurementInvoice.company_id == cid, ProcurementInvoice.is_demo == True).delete(synchronize_session=False)
    db.query(GoodsReceipt).filter(GoodsReceipt.company_id == cid, GoodsReceipt.is_demo == True).delete(synchronize_session=False)
    # quotes / rfqs / pos flagged demo
    qids = [q.id for q in db.query(ProcurementQuote).filter(ProcurementQuote.company_id == cid, ProcurementQuote.is_demo == True).all()]
    if qids:
        db.query(QuoteMemberScore).filter(QuoteMemberScore.quote_id.in_(qids)).delete(synchronize_session=False)
        db.query(ProcurementDocument).filter(ProcurementDocument.quote_id.in_(qids)).delete(synchronize_session=False)
    db.query(ProcurementQuote).filter(ProcurementQuote.company_id == cid, ProcurementQuote.is_demo == True).delete(synchronize_session=False)
    db.query(PurchaseOrder).filter(PurchaseOrder.company_id == cid).filter(PurchaseOrder.po_no.in_(["PO-0001", "PO-0002"])).delete(synchronize_session=False)
    db.query(ProcurementRFQ).filter(ProcurementRFQ.company_id == cid, ProcurementRFQ.is_demo == True).delete(synchronize_session=False)
    db.query(Vendor).filter(Vendor.company_id == cid, Vendor.is_demo == True).delete(synchronize_session=False)
    db.commit()
    return {"ok": True, "message": "Demo procurement data deleted"}



# ===== SPA (must be last routes) =====




# ---- Knowsoft branded error pages ----
from fastapi.responses import HTMLResponse

def _knowsoft_error_html(code: int, title: str, message: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>{code} — Knowsoft FMSS</title>
<style>
body{{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#0a0e17;color:#e8eef7;}}
.card{{background:#0f1724;border:1px solid #1e3a5f;border-radius:16px;padding:40px 36px;max-width:440px;text-align:center;}}
h1{{margin:0 0 8px;font-size:28px;color:#5eb3ff;}}
p{{margin:0 0 24px;color:#9bb0c9;line-height:1.5;}}
a.btn{{display:inline-block;padding:12px 28px;border-radius:8px;background:#00b4d8;color:#041018;
text-decoration:none;font-weight:600;}}
.logo{{font-size:42px;margin-bottom:12px;}}
</style></head><body>
<div class="card">
  <div class="logo">🛡️</div>
  <h1>Knowsoft FMSS</h1>
  <p><strong>{code} — {title}</strong><br/>{message}</p>
  <a class="btn" href="/">← Back to app</a>
</div>
</body></html>"""

@app.exception_handler(404)
async def knowsoft_404(request, exc):
    accept = request.headers.get("accept", "")
    if "text/html" in accept:
        return HTMLResponse(_knowsoft_error_html(404, "Page not found",
            "This page does not exist or was moved. Use Back to return to Knowsoft FMSS."), status_code=404)
    from fastapi.responses import JSONResponse
    return JSONResponse({"detail": "Not found"}, status_code=404)

@app.exception_handler(500)
async def knowsoft_500(request, exc):
    accept = request.headers.get("accept", "")
    if "text/html" in accept:
        return HTMLResponse(_knowsoft_error_html(500, "Something went wrong",
            "An unexpected error occurred. You can go back and continue working. If it persists, contact Knowsoft support."), status_code=500)
    from fastapi.responses import JSONResponse
    return JSONResponse({"detail": "Internal server error"}, status_code=500)


@app.get("/")
def serve_index():
    index = FRONTEND_DIR / "index.html"
    return FileResponse(index) if index.exists() else {"msg": "API up"}

@app.get("/{full_path:path}")
def serve_frontend(full_path: str):
    if full_path.startswith("api/") or full_path.startswith("static/"):
        raise HTTPException(404, "Not found")
    fp = FRONTEND_DIR / full_path
    if fp.exists() and fp.is_file():
        return FileResponse(fp)
    index = FRONTEND_DIR / "index.html"
    return FileResponse(index) if index.exists() else HTTPException(404)

